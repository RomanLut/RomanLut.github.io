/*****************************************************
CNC Controller
Copyright 2012-2013 by Roman Lut
www.deep-shadows.com/hax/

Chip type               : ATmega8535
AVR Core Clock frequency: 16,270000 MHz
*****************************************************/

#include <mega8535.h>
#include <stdio.h>
#include <spi.h>
#include <stdint.h>
#include <delay.h>
#include <usart.h>

// Declare your global variables here

#define DAC_LD  PORTB.4
#define DAC_CLK PORTB.7
#define DAC_DI  PORTB.5

//STEP masks
#define MASK_STEP1   1   //PORTB
#define MASK_STEP2   2   //PORTB
#define MASK_STEP3   4   //PORTB
#define MASK_STEP4   8  //PORTB

//DIR pins
#define PIN_DIR1    PIND.2
#define PIN_DIR2    PIND.3
#define PIN_DIR3    PIND.4
#define PIN_DIR4    PIND.7

#define REF_MIN_CURRENT  178
//#define REF_MIN_CURRENT  220
#define REF_MAX_CURRENT  (38)

//Miscrostep mode selection for each channel
//1 - microstep 16
//2 - microstep 8
//4 - microstep 4
//8 - halfstep 
//16 - full step
#define M1_SPEED  1                   //  165-1  
#define M2_SPEED  2                  //1 - 10292, 2 - 5146
#define M3_SPEED  2
#define M4_SPEED  1

//software max current limiting for each channel
//256 - max
//128 - half max curent
#define M1_CURRENTLIM 200   
#define M2_CURRENTLIM 128   
#define M3_CURRENTLIM 200    
#define M4_CURRENTLIM 128   

//software max current limiting for each channel in hold mode
//256 - max
//128 - half max curent
#define M1_CURRENTHOLD ( M1_CURRENTLIM / 2 )    
#define M2_CURRENTHOLD ( M2_CURRENTLIM / 2 )    
#define M3_CURRENTHOLD ( M3_CURRENTLIM / 2 )    
#define M4_CURRENTHOLD ( M4_CURRENTLIM / 2 )    

/*
//sinus positive half-period ( one arc )
const unsigned char __flash WTABLE_SIN0[32] = {  
                                    0, 25, 51, 75, 99, 122, 144, 164, 183, 199, 214, 226, 237, 245, 251, 254,  
                                    255, 254, 251, 245, 237, 226, 214, 199, 183, 164, 144, 122, 99, 75, 51,25
                                    }; 
*/

//----------------------------------------------------------------------------------------------------------------------------------
#define S1a(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M1_CURRENTLIM / 256 )
#define S1ha(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M1_CURRENTHOLD / 256 )

#define S1(x) S1a(x)
#define S1h(x) S1ha(x)

//#define S1(x) S1a(((uint32_t)x)*x/256)
//#define S1h(x) S1ha(((uint32_t)x)*x/256)

//#define S1(x) S1a(((uint32_t)x)*x*x*x/256/65536)
//#define S1h(x) S1ha(((uint32_t)x)*x*x*x/256/65536)


//sin(x)
const unsigned char __flash WTABLE_SIN1[ 32 + 32 + 16 + 32 + 32 + 16 ] = {  
    S1(0), S1(25), S1(51), S1(75), S1(99), S1(122), S1(144), S1(164), S1(183), S1(199), S1(214), S1(226), S1(237), S1(245), S1(251), S1(254),  
    S1(255), S1(254), S1(251), S1(245), S1(237), S1(226), S1(214), S1(199), S1(183), S1(164), S1(144), S1(122), S1(99), S1(75), S1(51), S1(25),

    S1(0), S1(25), S1(51), S1(75), S1(99), S1(122), S1(144), S1(164), S1(183), S1(199), S1(214), S1(226), S1(237), S1(245), S1(251), S1(254),  
    S1(255), S1(254), S1(251), S1(245), S1(237), S1(226), S1(214), S1(199), S1(183), S1(164), S1(144), S1(122), S1(99), S1(75), S1(51), S1(25),

    S1(0), S1(25), S1(51), S1(75), S1(99), S1(122), S1(144), S1(164), S1(183), S1(199), S1(214), S1(226), S1(237), S1(245), S1(251), S1(254),
    
    S1h(0), S1h(25), S1h(51), S1h(75), S1h(99), S1h(122), S1h(144), S1h(164), S1h(183), S1h(199), S1h(214), S1h(226), S1h(237), S1h(245), S1h(251), S1h(254),  
    S1h(255), S1h(254), S1h(251), S1h(245), S1h(237), S1h(226), S1h(214), S1h(199), S1h(183), S1h(164), S1h(144), S1h(122), S1h(99), S1h(75), S1h(51), S1h(25),
      
    S1h(0), S1h(25), S1h(51), S1h(75), S1h(99), S1h(122), S1h(144), S1h(164), S1h(183), S1h(199), S1h(214), S1h(226), S1h(237), S1h(245), S1h(251), S1h(254),  
    S1h(255), S1h(254), S1h(251), S1h(245), S1h(237), S1h(226), S1h(214), S1h(199), S1h(183), S1h(164), S1h(144), S1h(122), S1h(99), S1h(75), S1h(51), S1h(25),

    S1h(0), S1h(25), S1h(51), S1h(75), S1h(99), S1h(122), S1h(144), S1h(164), S1h(183), S1h(199), S1h(214), S1h(226), S1h(237), S1h(245), S1h(251), S1h(254)  
   }; 

/*
//sqrt(sin(x))
const unsigned char __flash WTABLE_SIN1[ 32 + 32 + 16 + 32 + 32 + 16 ] = {  
    S1(0), S1(80), S1(113), S1(137), S1(158), S1(175), S1(190), S1(203), S1(215), S1(224), S1(233), S1(239), S1(245), S1(249), S1(253), S1(254),  
    S1(255), S1(254), S1(253), S1(249), S1(245), S1(239), S1(233), S1(224), S1(215), S1(203), S1(190), S1(175), S1(158), S1(137), S1(113), S1(80),

    S1(0), S1(80), S1(113), S1(137), S1(158), S1(175), S1(190), S1(203), S1(215), S1(224), S1(233), S1(239), S1(245), S1(249), S1(253), S1(254),  
    S1(255), S1(254), S1(253), S1(249), S1(245), S1(239), S1(233), S1(224), S1(215), S1(203), S1(190), S1(175), S1(158), S1(137), S1(113), S1(80),

    S1(0), S1(25), S1(51), S1(75), S1(99), S1(122), S1(144), S1(164), S1(183), S1(199), S1(214), S1(226), S1(237), S1(245), S1(251), S1(254),
    
    S1h(0), S1h(80), S1h(113), S1h(137), S1h(158), S1h(175), S1h(190), S1h(203), S1h(215), S1h(224), S1h(233), S1h(239), S1h(245), S1h(249), S1h(253), S1h(254),  
    S1h(255), S1h(254), S1h(253), S1h(249), S1h(245), S1h(239), S1h(233), S1h(224), S1h(215), S1h(203), S1h(190), S1h(175), S1h(158), S1h(137), S1h(113), S1h(80),
      
    S1h(0), S1h(80), S1h(113), S1h(137), S1h(158), S1h(175), S1h(190), S1h(203), S1h(215), S1h(224), S1h(233), S1h(239), S1h(245), S1h(249), S1h(253), S1h(254),  
    S1h(255), S1h(254), S1h(253), S1h(249), S1h(245), S1h(239), S1h(233), S1h(224), S1h(215), S1h(203), S1h(190), S1h(175), S1h(158), S1h(137), S1h(113), S1h(80),

    S1h(0), S1h(80), S1h(113), S1h(137), S1h(158), S1h(175), S1h(190), S1h(203), S1h(215), S1h(224), S1h(233), S1h(239), S1h(245), S1h(249), S1h(253), S1h(254)  
   }; 
*/

//----------------------------------------------------------------------------------------------------------------------------------
#define S2(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M2_CURRENTLIM / 256 )
#define S2h(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M2_CURRENTHOLD / 256 )

const unsigned char __flash WTABLE_SIN2[ 32 + 32 + 16 + 32 + 32 + 16 ] = {  
    S2(0), S2(25), S2(51), S2(75), S2(99), S2(122), S2(144), S2(164), S2(183), S2(199), S2(214), S2(226), S2(237), S2(245), S2(251), S2(254),  
    S2(255), S2(254), S2(251), S2(245), S2(237), S2(226), S2(214), S2(199), S2(183), S2(164), S2(144), S2(122), S2(99), S2(75), S2(51), S2(25),

    S2(0), S2(25), S2(51), S2(75), S2(99), S2(122), S2(144), S2(164), S2(183), S2(199), S2(214), S2(226), S2(237), S2(245), S2(251), S2(254),  
    S2(255), S2(254), S2(251), S2(245), S2(237), S2(226), S2(214), S2(199), S2(183), S2(164), S2(144), S2(122), S2(99), S2(75), S2(51), S2(25),

    S2(0), S2(25), S2(51), S2(75), S2(99), S2(122), S2(144), S2(164), S2(183), S2(199), S2(214), S2(226), S2(237), S2(245), S2(251), S2(254),
    
    S2h(0), S2h(25), S2h(51), S2h(75), S2h(99), S2h(122), S2h(144), S2h(164), S2h(183), S2h(199), S2h(214), S2h(226), S2h(237), S2h(245), S2h(251), S2h(254),  
    S2h(255), S2h(254), S2h(251), S2h(245), S2h(237), S2h(226), S2h(214), S2h(199), S2h(183), S2h(164), S2h(144), S2h(122), S2h(99), S2h(75), S2h(51), S2h(25),
      
    S2h(0), S2h(25), S2h(51), S2h(75), S2h(99), S2h(122), S2h(144), S2h(164), S2h(183), S2h(199), S2h(214), S2h(226), S2h(237), S2h(245), S2h(251), S2h(254),  
    S2h(255), S2h(254), S2h(251), S2h(245), S2h(237), S2h(226), S2h(214), S2h(199), S2h(183), S2h(164), S2h(144), S2h(122), S2h(99), S2h(75), S2h(51), S2h(25),

    S2h(0), S2h(25), S2h(51), S2h(75), S2h(99), S2h(122), S2h(144), S2h(164), S2h(183), S2h(199), S2h(214), S2h(226), S2h(237), S2h(245), S2h(251), S2h(254)  
   }; 

//----------------------------------------------------------------------------------------------------------------------------------
#define S3a(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M3_CURRENTLIM / 256 )
#define S3ha(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M3_CURRENTHOLD / 256 )

#define S3(x) S3a(x)
#define S3h(x) S3ha(x)

//#define S3(x) S3a(((uint32_t)x)*x/256)
//#define S3h(x) S3ha(((uint32_t)x)*x/256)

//#define S3(x) S3a(((uint32_t)x)*x*x/65536)
//#define S3h(x) S3ha(((uint32_t)x)*x*x/65536)

//#define S3(x) S3a(((uint32_t)x)*x*x*x/256/65536)
//#define S3h(x) S3ha(((uint32_t)x)*x*x*x/256/65536)


const unsigned char __flash WTABLE_SIN3[ 32 + 32 + 16 + 32 + 32 + 16 ] = {  
    S3(0), S3(25), S3(51), S3(75), S3(99), S3(122), S3(144), S3(164), S3(183), S3(199), S3(214), S3(226), S3(237), S3(245), S3(251), S3(254),  
    S3(255), S3(254), S3(251), S3(245), S3(237), S3(226), S3(214), S3(199), S3(183), S3(164), S3(144), S3(122), S3(99), S3(75), S3(51), S3(25),

    S3(0), S3(25), S3(51), S3(75), S3(99), S3(122), S3(144), S3(164), S3(183), S3(199), S3(214), S3(226), S3(237), S3(245), S3(251), S3(254),  
    S3(255), S3(254), S3(251), S3(245), S3(237), S3(226), S3(214), S3(199), S3(183), S3(164), S3(144), S3(122), S3(99), S3(75), S3(51), S3(25),

    S3(0), S3(25), S3(51), S3(75), S3(99), S3(122), S3(144), S3(164), S3(183), S3(199), S3(214), S3(226), S3(237), S3(245), S3(251), S3(254),  
    
    S3h(0), S3h(25), S3h(51), S3h(75), S3h(99), S3h(122), S3h(144), S3h(164), S3h(183), S3h(199), S3h(214), S3h(226), S3h(237), S3h(245), S3h(251), S3h(254),  
    S3h(255), S3h(254), S3h(251), S3h(245), S3h(237), S3h(226), S3h(214), S3h(199), S3h(183), S3h(164), S3h(144), S3h(122), S3h(99), S3h(75), S3h(51), S3h(25),

    S3h(0), S3h(25), S3h(51), S3h(75), S3h(99), S3h(122), S3h(144), S3h(164), S3h(183), S3h(199), S3h(214), S3h(226), S3h(237), S3h(245), S3h(251), S3h(254),  
    S3h(255), S3h(254), S3h(251), S3h(245), S3h(237), S3h(226), S3h(214), S3h(199), S3h(183), S3h(164), S3h(144), S3h(122), S3h(99), S3h(75), S3h(51), S3h(25),

    S3h(0), S3h(25), S3h(51), S3h(75), S3h(99), S3h(122), S3h(144), S3h(164), S3h(183), S3h(199), S3h(214), S3h(226), S3h(237), S3h(245), S3h(251), S3h(254)  
   }; 

//----------------------------------------------------------------------------------------------------------------------------------
#define S4(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M4_CURRENTLIM / 256 )
#define S4h(x) ( REF_MIN_CURRENT - ( (((uint16_t)( x )) * ( REF_MIN_CURRENT - REF_MAX_CURRENT) ) / 255 ) * M4_CURRENTHOLD / 256 )

const unsigned char __flash WTABLE_SIN4[ 32 + 32 + 16 + 32 + 32 + 16 ] = {  
    S4(0), S4(25), S4(51), S4(75), S4(99), S4(122), S4(144), S4(164), S4(183), S4(199), S4(214), S4(226), S4(237), S4(245), S4(251), S4(254),  
    S4(255), S4(254), S4(251), S4(245), S4(237), S4(226), S4(214), S4(199), S4(183), S4(164), S4(144), S4(122), S4(99), S4(75), S4(51), S4(25),

    S4(0), S4(25), S4(51), S4(75), S4(99), S4(122), S4(144), S4(164), S4(183), S4(199), S4(214), S4(226), S4(237), S4(245), S4(251), S4(254),  
    S4(255), S4(254), S4(251), S4(245), S4(237), S4(226), S4(214), S4(199), S4(183), S4(164), S4(144), S4(122), S4(99), S4(75), S4(51), S4(25),

    S4(0), S4(25), S4(51), S4(75), S4(99), S4(122), S4(144), S4(164), S4(183), S4(199), S4(214), S4(226), S4(237), S4(245), S4(251), S4(254),  
    
    S4h(0), S4h(25), S4h(51), S4h(75), S4h(99), S4h(122), S4h(144), S4h(164), S4h(183), S4h(199), S4h(214), S4h(226), S4h(237), S4h(245), S4h(251), S4h(254),  
    S4h(255), S4h(254), S4h(251), S4h(245), S4h(237), S4h(226), S4h(214), S4h(199), S4h(183), S4h(164), S4h(144), S4h(122), S4h(99), S4h(75), S4h(51), S4h(25),

    S4h(0), S4h(25), S4h(51), S4h(75), S4h(99), S4h(122), S4h(144), S4h(164), S4h(183), S4h(199), S4h(214), S4h(226), S4h(237), S4h(245), S4h(251), S4h(254),  
    S4h(255), S4h(254), S4h(251), S4h(245), S4h(237), S4h(226), S4h(214), S4h(199), S4h(183), S4h(164), S4h(144), S4h(122), S4h(99), S4h(75), S4h(51), S4h(25),

    S4h(0), S4h(25), S4h(51), S4h(75), S4h(99), S4h(122), S4h(144), S4h(164), S4h(183), S4h(199), S4h(214), S4h(226), S4h(237), S4h(245), S4h(251), S4h(254)  
   }; 

//---------------------------------------------------------------------------------------------------------------------
#define _NF( x ) ( ( ~x ) & 0x0f )

const unsigned char __flash WTABLE_ONOFF[64] = {
       _NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),_NF(3),
       _NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),_NF(6),  
       _NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),_NF(12),
       _NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9),_NF(9)
     }; 

//USART Receive buffer                          
#define RXBUF_LENGTH 32
#define RXBUFINDEX_MASK 31                
char rxbuf[ RXBUF_LENGTH ];
uint8_t rxbufIndex;     

//========================
//========================
typedef struct
{
    //length of trajectory segment, ticks
    int16_t length;   
                          
    //bit 0 - X, bit 1 - Y, bit 2 - Z, bit 3 - W
    uint8_t stepDirection; 
    
    //X|Y|Z|W axis step period, ticks
    int16_t XStepPeriod;       
    int16_t YStepPeriod;       
    int16_t ZStepPeriod;       
    int16_t WStepPeriod;
    
    //X|Y|Z|W axis step phase( assume ticks already passed at the beginning of trajectory )
    int16_t XStepPhase;
    int16_t YStepPhase;
    int16_t ZStepPhase;
    int16_t WStepPhase;
} TTrajSegment;

//===============================================
//trajectory segments ring buffer

//current segment is pointed by trBufTailIndex
//trBufTailIndex == trBufHeadIndex means no job left  
uint8_t trBufHeadIndex;
uint8_t trBufTailIndex;

//number of segments todo in buffer
//includes current segment
uint8_t trBufCount;

TTrajSegment trBuf[ 8 ];
//===============================================

//current segment job left, ticks
//value -1 means no job
int16_t segLength;

int16_t XStepTicks; //number of ticks to pass before next X step 
int16_t YStepTicks; //number of ticks to pass before next Y step
int16_t ZStepTicks; //number of ticks to pass before next Z step
int16_t WStepTicks; //number of ticks to pass before next W step

//const uint8_t channelEncode[ 8 ] = { 8, 4, 12, 2, 10, 6, 14, 1 };
/*
//=========================================================
//=========================================================
void SPI_MasterTransmit(uint8_t cData)
{
    //Start transmission
    SPDR = cData;
    //Wait for transmission complete 
    while(!(SPSR & (1<<SPIF)));
}
*/

/*
//=========================================================
//=========================================================
void inline SPI_MasterTransmitNoWait(uint8_t cData)
{
    SPDR = cData;
}
*/

#define SPI_MasterTransmitNoWait(cData) { SPDR = cData; }

/*
//=========================================================
//=========================================================
void inline SPI_Wait()
{
   while(!(SPSR & (1<<SPIF)));
} 
*/

#define SPI_Wait() { while(!(SPSR & (1<<SPIF))); }

//=============================================================
//=============================================================
//activate segment pointed by trBufTail
void activateSegment()
{
    const TTrajSegment* p = &trBuf[ trBufTailIndex ];
    
    //segLenth contains negative value - extra ticks passed when processing previous segment
    //we ignore inaccuracy caused by -1 value in segLength  
    XStepTicks = p->XStepPeriod - p->XStepPhase + segLength;
    YStepTicks = p->YStepPeriod - p->YStepPhase + segLength;
    ZStepTicks = p->ZStepPeriod - p->ZStepPhase + segLength;
    WStepTicks = p->WStepPeriod - p->WStepPhase + segLength;        
    
    segLength += p->length;
}

//=============================================================
//=============================================================
void main(void)
{

uint8_t k;
uint8_t pos1,pos2,pos3,pos4;
uint8_t pb, pnew;
uint8_t hold_add;

union
{
    uint8_t b8[2];
    uint16_t w16;
} sleepCounter;

uint8_t lastTick;
uint8_t t,t1;
const TTrajSegment* p;
uint16_t dl,dl1;


// Declare your local variables here

// Input/Output Ports initialization
// Port A initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTA=0x00;
DDRA=0xFF;

// Port B initialization
// Func7=Out Func6=In Func5=Out Func4=Out Func3=In Func2=In Func1=In Func0=In 
// State7=1 State6=T State5=1 State4=1 State3=P State2=P State1=P State0=P 
PORTB=0xB0;
DDRB=0xB0;

// Port C initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTC=0x00;
DDRC=0xFF;

// Port D initialization
// Func7=In Func6=out Func5=Out Func4=In Func3=In Func2=In Func1=Out Func0=In 
// State7=P State6=T State5=0 State4=P State3=P State2=P State1=0 State0=T 
PORTD=0x00;
DDRD=0x62;


// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 254,219 kHz
// Mode: Normal top=0xFF
// OC0 output: Disconnected
TCCR0=0x03;
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 16270,000 kHz
// Mode: Fast PWM top=ICR1
// OC1A output: Non-Inv.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x82;
TCCR1B=0x19;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x7f;
OCR1AH=0x00;
OCR1AL=0x10;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=0x00;
MCUCSR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 19200
UCSRA=0x00;
UCSRB=0x18;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x34;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC disabled
ADCSRA=0x00;

// SPI initialization
// SPI Type: Master
// SPI Clock Rate: 2*4067,500 kHz
// SPI Clock Phase: Cycle Half
// SPI Clock Polarity: High
// SPI Data Order: MSB First
SPCR=0x5C;
SPSR=0x01;

// TWI initialization
// TWI disabled
TWCR=0x00;

    pos1 = 0;
    pos2 = 0;
    pos3 = 0;
    pos4 = 0;
        
    pb = PINB;
    
    hold_add = 0;
    sleepCounter.w16 = 0;
    
    rxbufIndex = 0;                             

    trBufHeadIndex = 0;    
    trBufTailIndex = 0;    
    trBufCount = 0;        
    
    segLength = -1;
    
    dl=250;
         
    while (1)
    {                   
       //PORTD.6 = PIND.7;
        
        //dl++;
        PORTD.6 = ~PORTD.6;

        pnew = PINB;

        //Detect raising front on pins of port b
        //Rising front generates bit = 1 in variable k        
        k = ( pb ^ pnew ) & pnew;
        
        if ( k & MASK_STEP1 )
        //if ( true )
        {
            if ( PIN_DIR1 )
            {    
                pos1 += M1_SPEED;
            }
            else
            {
                pos1 += -M1_SPEED;
            }
           pos1 &= 63;
           sleepCounter.b8[1] = 0;
        } 
          
        
        if ( k & MASK_STEP2 )
        //if ( true )
        {
            if ( PIN_DIR2 )
            {
                pos2 += M2_SPEED;
            }
            else
            {
                pos2 += -M2_SPEED;
            }
            pos2 &= 63;     
            sleepCounter.b8[1] = 0;
        }          
        
        if ( k & MASK_STEP3 )
        {
            if ( PIN_DIR3 )
            {
                pos3 += M3_SPEED;                
            }
            else
            {
                pos3 += -M3_SPEED;
            }
            pos3 &= 63;      
            sleepCounter.b8[1] = 0;
        }           
        
        if ( k & MASK_STEP4 )
        {
            if ( PIN_DIR4 )
            {
                pos4 += M4_SPEED;
            }
            else
            {
                pos4 += -M4_SPEED;
            }
            pos4 &= 63;      
            sleepCounter.b8[1] = 0;
        }             
        
        pb = pnew;
        
        //================================
        //if ( segLength >= 0 )
        if ( ( segLength & 0x8000 ) == 0 )  //efficient check "not negative value" ( >=0 )
        {
        
                                //USART_TransmitBuf( (unsigned char*)&XStepTicks, 2 );    
                         
                    
            sleepCounter.b8[1] = 0;
                   
            t1 = TCNT0;   
            t = t1 - lastTick; 
            lastTick = t1;    
            
            if ( t > 220 )
            {
                USART_TransmitCharNoWait( 255 );
            }   
            
            
            //t - 15KHz ticks passed from last time
            p = &trBuf[ trBufTailIndex ];
                   
            XStepTicks -= t;
            if ( ( XStepTicks ) <= 0 )
            {      
                XStepTicks += p->XStepPeriod;
                
                if ( ( p->stepDirection & 1 ) == 0 )
                {    
                    pos1 += M1_SPEED;
                }
                else
                {
                    pos1 += -M1_SPEED;
                }
               pos1 &= 63;
            }   
                   
            YStepTicks -= t;
            if ( ( YStepTicks ) <= 0 )
            {      
                YStepTicks += p->YStepPeriod;
                
                if ( ( p->stepDirection & 2 ) == 0 )
                {    
                    pos2 += M2_SPEED;
                }
                else
                {
                    pos2 += -M2_SPEED;
                }
               pos2 &= 63;
            }   
                                  
            ZStepTicks -= t;
            if ( ( ZStepTicks ) <= 0 )
            {      
                ZStepTicks += p->ZStepPeriod;
                
                if ( ( p->stepDirection & 4 ) == 0 )
                {    
                    pos3 += M3_SPEED;
                }
                else
                {
                    pos3 += -M3_SPEED;
                }
               pos3 &= 63;
            }   
                   
            WStepTicks -= t;
            if ( ( WStepTicks ) <= 0 )
            {      
                WStepTicks += p->WStepPeriod;
                
                if ( ( p->stepDirection & 8 ) == 0 )
                {    
                    pos4 += M4_SPEED;
                }
                else
                {
                    pos4 += -M4_SPEED;
                }
               pos4 &= 63;
            }   
                                 
            segLength -= t;
            if ( segLength <= 0 )
            {
                trBufTailIndex++;
                trBufTailIndex &= 7;          
                                 
                trBufCount--;
                if ( trBufCount > 0 )
                {
                    activateSegment();
                }                     
                else
                {
                    segLength = -1;
                }
                      
            }                        
        }
        
        //================================
        
        //if ( sleepCounter > 65000 )
        if ( sleepCounter.b8[1] == 0xff )
        {   
            hold_add = 32 + 32 + 16;
        }      
        else
        {                           
            hold_add = 0;
            sleepCounter.w16++;
        }
                                      
        //============== 1 ===============        
        DAC_LD = 0;
     
        SPI_MasterTransmitNoWait( 8 << 2 );

        //k = ( pos0 + 16 ) & 31;     
        //k = WTABLE_SIN1[ k ];
        k = WTABLE_SIN1[ pos1 + hold_add + 16 ];        
        
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
        SPI_Wait();

        DAC_LD = 1;
        DAC_LD = 0;

        SPI_MasterTransmitNoWait( 4 << 2 );

        //k = pos0 & 31;     
        //k = WTABLE_SIN1[ k ];
        k = WTABLE_SIN1[ pos1 + hold_add ];
        
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
             
        PORTA = ( PORTA & 0xf0 ) | ( WTABLE_ONOFF[ pos1 ] );  
    
        SPI_Wait();

        DAC_LD = 1;
                                     
        //============= 2 =============================
        DAC_LD = 0;
     
        SPI_MasterTransmitNoWait( 12 << 2 );

        k = WTABLE_SIN2[ pos2 + hold_add + 16 ];
        
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
        SPI_Wait();
        
        DAC_LD = 1;
        DAC_LD = 0;

        SPI_MasterTransmitNoWait( 2 << 2 );

        k = WTABLE_SIN2[ pos2 + hold_add ];
        
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
    
        PORTA = ( PORTA & 0x0f ) | ( WTABLE_ONOFF[ pos2 ] << 4 );  
    
        SPI_Wait();

        DAC_LD = 1;
    
        //============= 3 =============================
        DAC_LD = 0;
     
        SPI_MasterTransmitNoWait( 10 << 2 );

        k = WTABLE_SIN3[ pos3 + hold_add + 16 ];
    
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
        SPI_Wait();
        
        DAC_LD = 1;    
        DAC_LD = 0;

        SPI_MasterTransmitNoWait( 6 << 2 );
        
        k = WTABLE_SIN3[ pos3 + hold_add ];
        
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
    
        PORTC = ( PORTC & 0xf0 ) | ( WTABLE_ONOFF[ pos3 ] );  
    
        SPI_Wait();

        DAC_LD = 1;
             
        
        //============= 4 =============================
        DAC_LD = 0;
     
        SPI_MasterTransmitNoWait( 14 << 2 );
                                      
        k = WTABLE_SIN4[ pos4 + hold_add + 16 ];
    
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
        SPI_Wait();
        DAC_LD = 1;
            
        DAC_LD = 0;

        SPI_MasterTransmitNoWait( 1 << 2 );

        k = WTABLE_SIN4[ pos4 + hold_add ];
    
        SPI_Wait();
        SPI_MasterTransmitNoWait( k );
    
        PORTC = ( PORTC & 0x0f ) | ( WTABLE_ONOFF[ pos4  ] << 4 );  
    
        SPI_Wait();

        DAC_LD = 1;
         
        //==============================================
           
        if ( USART_HasData() )
        {
            k = USART_ReceiveCharNoWait();
            USART_TransmitChar( k );

            if ( k == 0x0a )
            {
                k = 0xd;
            }
                   
            rxbuf[ rxbufIndex ] = k;
            rxbufIndex = ( rxbufIndex + 1 ) & RXBUFINDEX_MASK;

            switch ( k ) 
            {
                case 'X':
                    pos1 += M1_SPEED;
                    pos1 &= 63;
                    rxbufIndex = 0;
                    break;
                case 'x':
                    pos1 += -M1_SPEED;
                    pos1 &= 63;
                    rxbufIndex = 0;
                    break;
    
                case 'Y':
                    pos2 += M1_SPEED;
                    pos2 &= 63;
                    rxbufIndex = 0;
                    break;
                case 'y':
                    pos2 += -M1_SPEED;
                    pos2 &= 63;
                    rxbufIndex = 0;
                    break;
    
                case 'Z':
                    pos3 += M1_SPEED;
                    pos3 &= 63;
                    rxbufIndex = 0;
                    break;
                case 'z':
                    pos3 += -M1_SPEED;
                    pos3 &= 63;
                    rxbufIndex = 0;
                    break;
    
                case 'W':
                    pos4 += M1_SPEED;
                    pos4 &= 63;
                    rxbufIndex = 0;
                    break;
                case 'w':
                    pos4 += -M1_SPEED;
                    pos4 &= 63;
                    rxbufIndex = 0;
                    break;     
                        
                case 'S': //stop, discard current trajectory
                    segLength = -1;
                    trBufCount = 0;
                    trBufHeadIndex = 0;
                    trBufTailIndex = 0;
                    rxbufIndex = 0;
                    break;
                    
                case 'o':
                    dl--;
                    break;                         
                case 'p':
                    dl++;
                    break;                         
                                             
            } //switch

            if ( k == 0x0d )
            {         
                switch ( rxbuf[ 0 ] ) 
                {
                    case 'T': 
                        //append trajectory point, all values are in 15KHz ticks 
                        //LL - segment length, ticks
                        //D - step direction bitfield 
                        //XX - X axis step period, ticks 
                        //YY - Y axis step period, ticks 
                        //ZZ - Z axis step period, ticks 
                        //WW - W axis step period, ticks
                        //xx - X axis step phase, tick ( assume ticks already passed )
                        //yy - Y axis step phase, tick ( assume ticks already passed )
                        //zz - Z axis step phase, tick ( assume ticks already passed )
                        //ww - W axis step phase, tick ( assume ticks already passed )
                        //total 20 bytes + cr = 21 bytes
                        //directly maps to TTrajSegment
                        
                        trBuf[ trBufHeadIndex ] = *( ( TTrajSegment *)&(rxbuf[ 1 ]) );
                        trBufHeadIndex++;
                        trBufHeadIndex &= 7;

                        trBufCount++;
                                     
                        if ( trBufCount == 1 )
                        {
                            activateSegment();
                            lastTick = TCNT0;
                        }
                        
                        USART_TransmitChar( trBufCount + '0' );                       

                                USART_TransmitBuf( (unsigned char*)&XStepTicks, 2 );    
                        
                        break;
                } //switch
                rxbufIndex = 0;
            } //k == 0xd
            sleepCounter.b8[1] = 0;
        }//hasdata
  
          
        /*               
        for ( dl1 = 0; dl1 < dl; dl1++ )
        {
            delay_us(1);
        } 
        */
      } //while(1)      

}
