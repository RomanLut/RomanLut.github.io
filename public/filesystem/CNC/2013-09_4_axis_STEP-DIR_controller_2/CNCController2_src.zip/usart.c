#include "usart.h"
#include <mega8535.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

//======================================================
//======================================================
void USART_TransmitChar( unsigned char data )
{
/* Wait for empty transmit buffer */
    while ( !( UCSRA & (1<<UDRE)) )
    ;
    /* Put data into buffer, sends the data */
    UDR = data;
}

//======================================================
//======================================================
void USART_TransmitCharNoWait( unsigned char data )
{
/* Wait for empty transmit buffer */
    if ( !( UCSRA & (1<<UDRE)) )
    {
        return;
    }
   /* Put data into buffer, sends the data */
    UDR = data;
}

//======================================================
//======================================================
void USART_TransmitBuf( unsigned const char* data, int data_len )
{
    while ( data_len > 0 )
    {
        USART_TransmitChar( *data );
        data++;
        data_len--;
    }
}


//======================================================
//======================================================
bool USART_HasData()
{
    return ( (UCSRA & (1<<RXC) ) != 0 );
}

//======================================================
//======================================================
unsigned char USART_ReceiveChar()
{
    /* Wait for data to be received */
    while ( !(UCSRA & (1<<RXC)) )
    ;
    /* Get and return received data from buffer */
    return UDR;
}

//======================================================
//======================================================
unsigned char USART_ReceiveCharNoWait()
{
    return UDR;
}

//======================================================
//======================================================
void USART_sprintf( flash unsigned const char* fmt, ... )
{
    char buf[ 100 ];
     
    va_list argptr;
    va_start( argptr, fmt );
    
    vsprintf( buf, fmt, argptr );
    
    va_end( argptr );
     
    USART_TransmitBuf( buf, strlen( buf ) );
}
