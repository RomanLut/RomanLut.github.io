/*****************************************************
Step/Dir controller for 3 stepper motors.

Chip type               : ATtiny2313
AVR Core Clock frequency: 8,000000 MHz
Memory model            : Tiny
External RAM size       : 0
Data Stack size         : 32
*****************************************************/

#include <tiny2313.h>

/*********************************************************
Driver configuration:

Each channel can work in one of three modes:
- 4-step microstep
- half-step
- full phase full step
- half-phase full step

Channel (A,B,C) mode is configured by setting #defines  

for 4-step microstep:
        PHASE 0
        ADD   1
        SHR   0

for half-step:
        PHASE 0
        ADD   2
        SHR   0 ( 0 - normal moment at half step, 1 - large moment at half step) 

for full phase full step:
        PHASE 0
        ADD   4
        SHR   0

for half-phase full step:
        PHASE 2
        ADD   4
        SHR   0 ( 0 - normal moment, 1 - large moment) 

******************************************************************/

// Channel A configuration  
#define A_PHASE        0       
#define A_ADD          1
#define A_SHR          0

// Channel B configuration  
#define B_PHASE        0       
#define B_ADD          1
#define B_SHR          0

// Channel C configuration  
#define C_PHASE        0       
#define C_ADD          1
#define C_SHR          0


//*********************************************************
//1/4 sin table = 0.3826, 0.7071, 0.9238, 1     
//1/4 cos table = 1, 0.9238, 0.7071, 0.3826, 0
//*********************************************************

// Current table for coil 1
const unsigned char WTABLE1[16] = {  
                                    128, 118,  91,  49,  
                                    0,0,0,0,
                                    0,0,0,0,
                                    0, 49, 91, 118,
                                    }; 

// Current table for coil 2
const unsigned char WTABLE2[16] = {
                                    0, 49, 91, 118,
                                    128, 118,  91,  49,  
                                    0,0,0,0,
                                    0,0,0,0,
                                    }; 

// Current table for coil 3
const unsigned char WTABLE3[16] = {
                                    0,0,0,0,
                                    0, 49, 91, 118,
                                    128, 118,  91,  49,  
                                    0,0,0,0
                                    }; 

// Current table for coil 4
const unsigned char WTABLE4[16] = {
                                    0,0,0,0,
                                    0,0,0,0,
                                    0, 49, 91, 118,
                                    128, 118,  91,  49,  
                                    }; 


//PORTB value storage. Used to detect rising edges.
unsigned char pb;  

// Channel A position 
unsigned char stepA; 
// Channel B position 
unsigned char stepB; 
// Channel C position 
unsigned char stepC; 

// Temporary variables
unsigned char t,t1; 
unsigned char pb_new;
unsigned char ind;
unsigned char b;

// Inactivity couter
unsigned int sleepCount = 0;

//***************************************
// void main()
//***************************************
void main(void)
{
#pragma optsize-
#ifdef _OPTIMIZE_SIZE_
#pragma optsize+
#endif

        // Crystal Oscillator division factor: 1
        CLKPR=0x80;
        CLKPR=0x00;


        // Input/Output Ports initialization
        // Port A initialization
        // Func2=In Func1=Out Func0=Out 
        // State2=P State1=0 State0=0 
        PORTA=0x04;
        DDRA=0x03;


        // Port B initialization
        // Func7=In Func6=In Func5=In Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
        // State7=P State6=P State5=P State4=0 State3=0 State2=0 State1=0 State0=0 
        PORTB=0xE0;
        DDRB=0x1F;


        // Port D initialization
        // Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=In Func0=In 
        // State6=0 State5=0 State4=0 State3=0 State2=0 State1=P State0=P 
        PORTD=0x03;
        DDRD=0x7C;

        // Timer/Counter 0 initialization
        // Clock source: System Clock
        // Clock value: 1000,000 kHz
        // Mode: Normal top=FFh
        // OC0A output: Disconnected
        // OC0B output: Disconnected
        TCCR0A=0x00;
        TCCR0B=0x02;
        TCNT0=0x00;
        OCR0A=0x00;
        OCR0B=0x00;      

        // Timer/Counter 1 initialization
        // Clock source: System Clock
        // Clock value: Timer1 Stopped
        // Mode: Normal top=FFFFh
        // OC1A output: Discon.
        // OC1B output: Discon.
        // Noise Canceler: Off
        // Input Capture on Falling Edge
        // Timer1 Overflow Interrupt: Off
        // Input Capture Interrupt: Off
        // Compare A Match Interrupt: Off
        // Compare B Match Interrupt: Off
        TCCR1A=0x00;
        TCCR1B=0x00;
        TCNT1H=0x00;
        TCNT1L=0x00;
        ICR1H=0x00;
        ICR1L=0x00;
        OCR1AH=0x00;
        OCR1AL=0x00;
        OCR1BH=0x00;
        OCR1BL=0x00;

        // External Interrupt(s) initialization
        // INT0: Off
        // INT1: Off
        // Interrupt on any change on pins PCINT0-7: Off
        GIMSK=0x00;
        MCUCR=0x00;

        // Timer(s)/Counter(s) Interrupt(s) initialization
        TIMSK=0x00;

        // Universal Serial Interface initialization
        // Mode: Disabled
        // Clock source: Register & Counter=no clk.
        // USI Counter Overflow Interrupt: Off
        USICR=0x00;

        // Analog Comparator initialization
        // Analog Comparator: Off
        // Analog Comparator Input Capture by Timer/Counter 1: Off
        ACSR=0x80;


        pb = PINB;

        stepA = A_PHASE;
        stepB = B_PHASE;
        stepC = C_PHASE;
        
        
        
        // main loop
        while (1)
        {
                // Get current timer value ( BYTE 0..255)
                //convert to 0..127
                t = TCNT0 & 0x7f;
        
                if ( sleepCount > 65534 )
                {                                                          
                        // after  about 2 sec of inactivity (sleepcount>65534), 
                        // multiply timer value by 2.
                        // this effectively decreses x0.5 active pulses widths in PWM
                        t = t << 1;
                }
                else
                {
                        sleepCount++;
                }
               
        pb_new = PINB;

        //Detect raising front on pins of port b
        //Rising front generates bit = 1 in variable b        
        b = ( pb ^ pb_new ) & pb_new;
        
        // If rising front on STEPA detected,
        //encrease/decrease PWM table index according to DIRA
        if ( ( b & 32 ) != 0 )
        {
                if (PIND.0 != 0 )
                {  
                        stepA += A_ADD;
                }
                else               
                {                
                        stepA -= A_ADD;
                }
                sleepCount = 0;                                                 
        }

        // If rising front on STEPB detected,
        //encrease/decrease PWM table index according to DIRB
        if ( ( b & 64 ) != 0 )
        {
                if ( PIND.1 != 0 )
                {  
                        stepB += B_ADD;
                }
                else
                {
                        stepB -= B_ADD;
                }
                sleepCount = 0;                                                 
        }

        // If rising front on STEPC detected,
        //encrease/decrease PWM table index according to DIRC
        if ( ( b & 128 ) != 0 )
        {
                if ( PINA.2 != 0)
                {  
                        stepC += C_ADD;
                }
                else
                {
                        stepC -= C_ADD;
                }
                sleepCount = 0;                                                 
        }
        
        pb = pb_new;

        //configure output pins
        
        // use lower 4 bits to index tables 
        ind = stepA & 15;
        
        //t1 is current timer value used to compare with current value from table
        // t1 < WTABLE1[ind] is effectively an output level for a given moment.
        // In cycle, this gives a PWM on output pins.   
        t1 = t >> A_SHR;
                
        b = 0xE0;                
        if ( t1 < WTABLE1[ind] ) b |= 1;
        if ( t1 < WTABLE2[ind] ) b |= 2;
        if ( t1 < WTABLE3[ind] ) b |= 4;
        if ( t1 < WTABLE4[ind] ) b |= 8;

        ind = stepB & 15;
        t1 = t >> B_SHR;
        
        if ( t1 < WTABLE1[ind] ) b |= 16;
        
        PORTB = b;

        b = 0x03;
        
        if ( t1 <= WTABLE2[ind] ) b |= 4;
        if ( t1 <= WTABLE3[ind] ) b |= 8;
        if ( t1 <= WTABLE4[ind] ) b |= 16;

        ind = stepC & 15;
        t1 = t >> C_SHR;
        
        if ( t1 <= WTABLE1[ind] )  b |= 32;
        if ( t1 <= WTABLE2[ind] )  b |= 64;
        
        PORTD = b;

        b = 0x04;

        if ( t1 <= WTABLE3[ind] ) b |= 1;
        if ( t1 <= WTABLE4[ind] ) b |= 2;
        
        PORTA = b;

      };
}
