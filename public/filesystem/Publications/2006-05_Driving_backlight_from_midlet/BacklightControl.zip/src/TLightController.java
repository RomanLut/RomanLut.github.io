//*******************************************************************************
//*******************************************************************************
// Universal backlight control class
// Copyright (C) 2006 by Roman Lut
// Free for any use. Please credit me in "About" box :)
//*******************************************************************************
//*******************************************************************************
/*
Singleton. Reference with TLightController.GetInstance()
Default state is ENABLE.

Query TLightController.GetInstance(midlet).CanControl() to see wheether class is able to control backlight.
Query TLightController.GetInstance(midlet).CanControlBrightness() to see wheether class is able to control brightness.
Use TLightController.GetInstance(midlet).SetBrightness(brightness) to control backlight brightness.
brightness is 0 (minimum) to 255 (maximum);

 Controlling method is determined automatically.
*/

import javax.microedition.midlet.*;
import com.siemens.mp.game.Light;
import com.nokia.mid.ui.DeviceControl;
import com.motorola.multimedia.Lighting;
import com.motorola.funlight.*;
import javax.microedition.lcdui.Display;
import java.util.Timer;
import java.util.TimerTask;
import com.samsung.util.LCDLight;
import mmpp.media.BackLight;

//=============================================
// TLightController
//=============================================
public class TLightController extends TimerTask
{
 //light control method
 private static final byte LIGHT_NONE               = 0;
 private static final byte LIGHT_SIEMENS            = 1;
 private static final byte LIGHT_NOKIA              = 2;
 private static final byte LIGHT_MOTOROLA_LIGHT     = 3;
 private static final byte LIGHT_MOTOROLA_FUNLIGHT  = 4;
 private static final byte LIGHT_SAMSUNG            = 5;
 private static final byte LIGHT_LG                 = 6;
 private static final byte LIGHT_MIDP20             = 7;

 private byte method;
 private static TLightController inst = null;

 private Region r1,r2,r3;
 Timer   funLightsTimer;

 //---- for timertask -----
 private static MIDlet midlet;
 private static int curBrightness;
 //------------------------

 //============================
 // void ApplyState()
 //============================
 private final void ApplyState()
 {
  switch (method)
  {
   case LIGHT_SIEMENS:
    {
     if (curBrightness>0)
      {
       Light.setLightOn();
      }
       else
      {
       Light.setLightOff();
      }
    }
   break;

   case LIGHT_NOKIA:
    {
     DeviceControl.setLights(0,curBrightness*100/255);
    }
   break;

   case LIGHT_MOTOROLA_LIGHT:
    if (curBrightness>0)
     {
      com.motorola.multimedia.Lighting.backlightOn();
     }
      else
     {
      com.motorola.multimedia.Lighting.backlightOff();
     }
   break;

   case LIGHT_MOTOROLA_FUNLIGHT:
    int c = curBrightness + (curBrightness << 8) + (curBrightness << 16);
    FunLight.getRegion(1).setColor(c);
    r1.setColor(0);
    r2.setColor(0);
    r3.setColor(0);
   break;

   case LIGHT_SAMSUNG:
    if (curBrightness>0)
     {
      com.samsung.util.LCDLight.on(0x0fffffff);  //max 60 seconds ?
     }
      else
     {
      com.samsung.util.LCDLight.off();
     }
   break;

   case LIGHT_LG:
    if (curBrightness>0)
     {
      mmpp.media.BackLight.on(0x0fffffff);
     }
      else
     {
      mmpp.media.BackLight.off();
     }
   break;

//#MIDP20{
   case LIGHT_MIDP20:
    if (curBrightness>0)
     {
      javax.microedition.lcdui.Display.getDisplay(midlet).flashBacklight(0x7fffffff);
     }
      else
     {
      javax.microedition.lcdui.Display.getDisplay(midlet).flashBacklight(0);
     }
   break;
//#MIDP20}
  }

 }

 //============================
 // run() (timer task)
 //============================
 public final void run()
 {
  ApplyState();
 }

 //=============================================
 // public TLightController()
 //=============================================
 private TLightController(MIDlet midlet)
 {
  curBrightness=(byte)255;
  this.midlet=midlet;

//#DEBUG{
//#DEBUG:  System.out.println("Initializing light controller");
//#DEBUG:  System.out.println("microedition.profiles = "+System.getProperty("microedition.profiles"));
//#DEBUG}

  method = LIGHT_NONE;

  try
  {
   Class.forName("com.siemens.mp.game.Light");
//#DEBUG{
//#DEBUG:   System.out.println("Using com.siemens.mp.game.Light");
//#DEBUG}
   method = LIGHT_SIEMENS;
  }
  catch (Exception e)
  {

  try
  {
   Class.forName("com.nokia.mid.ui.DeviceControl");
//#DEBUG{
//#DEBUG:   System.out.println("Using com.nokia.mid.ui.DeviceControl");
//#DEBUG}
   method = LIGHT_NOKIA;
  }
  catch (Exception e3)
  {

  try
  {
   Class.forName("com.motorola.funlight.FunLight");
//#DEBUG{
//#DEBUG:   System.out.println("Using com.motorola.multimedia.FunLight");
//#DEBUG}
   method = LIGHT_MOTOROLA_FUNLIGHT;
  }

  catch (Exception e1)
  {

  try
  {
   Class.forName("com.motorola.multimedia.Lighting");
//#DEBUG{
//#DEBUG:   System.out.println("Using com.motorola.multimedia.Lighting");
//#DEBUG}
   method = LIGHT_MOTOROLA_LIGHT;
  }
  catch (Exception e2)
  {


  try
  {
   Class.forName("com.samsung.util.LCDLight");

   if (LCDLight.isSupported()==false)
    {

//#DEBUG{
//#DEBUG:     System.out.println("LCDLight present, but not supported");
//#DEBUG}
     throw new Exception();
    }
//#DEBUG{
//#DEBUG:   System.out.println("Using com.samsung.LCDLight");
//#DEBUG}

   method = LIGHT_SAMSUNG;
  }
  catch (Exception e4)
  {

  try
  {
   Class.forName("mmpp.media.BackLight");

//#DEBUG{
//#DEBUG:   System.out.println("mmpp.media.BackLight");
//#DEBUG}

   method = LIGHT_LG;
  }
  catch (Exception e5)
  {

//#MIDP20{

   if (System.getProperty("microedition.profiles").indexOf("2.0")>0)
    {
//#DEBUG{
//#DEBUG:     System.out.println("javax.microedition.lcdui.Display");
//#DEBUG}
     method = LIGHT_MIDP20;
    }

//#MIDP20}

  }
  }
  }
  }
  }
  }

  if (method == LIGHT_MOTOROLA_FUNLIGHT)
   {
    FunLight.getControl();
    r1 = FunLight.getRegion(2);
    r2 = FunLight.getRegion(3);
    r3 = FunLight.getRegion(4);

    funLightsTimer = new Timer();
    funLightsTimer.scheduleAtFixedRate(this,0,100);
   }
    else
   {
    funLightsTimer = new Timer();
    funLightsTimer.scheduleAtFixedRate(this,0,3000);
   }
  ApplyState();
 }

 //=============================================
 //GetInstance()
 //=============================================
 public static TLightController GetInstance(MIDlet midlet)
 {
  if (inst==null) inst = new TLightController(midlet);
  return inst;
 }

 //=============================================
 //public boolean CanControl()
 //=============================================
 public boolean CanControl()
 {
  return method!=LIGHT_NONE;
 }

 //=============================================
 //public boolean CanControlBrightness()
 //=============================================
 public boolean CanControlBrightness()
 {
  return (method==LIGHT_NOKIA) || (method==LIGHT_MOTOROLA_FUNLIGHT);
 }

 //=============================================
 //public void SetBrightness()
 //=============================================
 public void SetBrightness(int brightness)
 {
  if (curBrightness == brightness) return;
  curBrightness = brightness;
  ApplyState();
 }
}

