
import javax.microedition.lcdui.*;

public class Displayable1 extends Form implements CommandListener
{
 private Gauge gauge;
 
 public Displayable1()
 {
  super("Backlight");
  try
  {
   jbInit();
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
 }

 private void jbInit() throws Exception
 {
  gauge = new Gauge("Light level",
             false,
             100,
             60);
             
  append(gauge);           
             
  setCommandListener(this);

  addCommand(new Command("Less", Command.CANCEL, 1));
  addCommand(new Command("More", Command.OK, 1));
  
  TLightController.GetInstance(MIDlet1.instance).SetBrightness(60*255/100);
 }

 public void commandAction(Command command, Displayable displayable)
 {
  if (command.getCommandType() == Command.OK)
  {
    if (gauge.getValue()<100) gauge.setValue(gauge.getValue()+20);
  }
   else
  if (command.getCommandType() == Command.CANCEL)
  {
    if (gauge.getValue()>0) gauge.setValue(gauge.getValue()-20);
  }
  
  TLightController.GetInstance(MIDlet1.instance).SetBrightness(gauge.getValue()*255/100);
 }

}
