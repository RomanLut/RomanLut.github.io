
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class MIDlet1 extends MIDlet
{
 public static MIDlet1 instance;
 private Displayable1 displayable = new Displayable1();

 /** Constructor */
 public MIDlet1()
 {
  instance = this;
 }

 /** Main method */
 public void startApp()
 {
  Display.getDisplay(this).setCurrent(displayable);
 }

 /** Handle pausing the MIDlet */
 public void pauseApp()
 {
 }

 /** Handle destroying the MIDlet */
 public void destroyApp(boolean unconditional)
 {
 }

 /** Quit the MIDlet */
 public static void quitApp()
 {
  instance.destroyApp(true);
  instance.notifyDestroyed();
  instance = null;
 }

}
