Universal backlight control class
Copyright (C) 2006 by Roman Lut

\src - TLightController class and example project sources
\bin\debug\ - debug version, with console output
\bin\release - release version

Both versions include MIDP2.0 method (checking microedition.profles).


Roman Lut
hax@deep-shadows.com
http://www.deep-shadows.com/hax/