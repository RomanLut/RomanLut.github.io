//=============================================
// class TEvent
// simple object for thread synchronization
// One thread waits for event, other signals
// usually used in consumer-producer pattern
// Copyright (c) 2005 by Roman Lut
//=============================================

#ifndef TEVENT_INCLUDED
#define TEVENT_INCLUDED

#include <windows.h>

//============================
// class TEvent
//============================
class TEvent
{
 private:
  HANDLE eventHandle;

 public:
  
  TEvent()
  {
   eventHandle=CreateEvent(NULL,false,false,NULL);
  }
  
  ~TEvent()
  {
   CloseHandle(eventHandle);
  }
  
 
  void FireEvent()
  {
   SetEvent(eventHandle);
  }
  
  void ResetEvent()
  {
   ::ResetEvent(eventHandle);
  }

  bool WaitForEvent(DWORD period_ms=INFINITE)
  {
   return WaitForSingleObject(eventHandle,period_ms)==WAIT_OBJECT_0;
  }

  HANDLE GetHandle()
  {
   return eventHandle;
  }

};


#endif TEVENT_INCLUDED
