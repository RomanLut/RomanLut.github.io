//---------------------------------------------------------------------------

#ifndef ThreadFuncH
#define ThreadFuncH
//---------------------------------------------------------------------------

#include <vcl.h>
#include <Windows.h>
#include "TEvent.h"
#include "TMatrix4x4.h"

const int MAX_TICKS = 300000;


//===================================
// TMyThreadData
//===================================
class TMyThreadData
{
 public:
  LARGE_INTEGER frequency;
  LARGE_INTEGER* tickStorage;  //MAX_TICKS
  LARGE_INTEGER startTime;
  LARGE_INTEGER exitTime;

  //------------------
  bool callSleep0;
  bool callSleep1;
  bool callSleep2; //call sleep 2 every 18 ms
  bool callSleep10;  //work 2 ms, call sleep 10
  bool fireStartingEvent;
  bool useCS;
  bool waitForEvent;
  volatile bool bExit;
  //------------------

  LARGE_INTEGER workDone;
  HAXMATH::TMATRIX4x4 m;

  TMyThreadData()
  {
   QueryPerformanceFrequency(&frequency);
   tickStorage = new LARGE_INTEGER[MAX_TICKS];
   memset(tickStorage, 0, sizeof(LARGE_INTEGER)*MAX_TICKS);
   callSleep0 = false;
   callSleep1 = false;
   callSleep2 = false;
   callSleep10 = false;
   fireStartingEvent = false;
   workDone.QuadPart=0;
   useCS = false;
   waitForEvent = false;
   bExit=false;
  }

  ~TMyThreadData()
  {
   delete[] tickStorage;
  }

  void Convert(LARGE_INTEGER start)
  {
   for (DWORD i=0; i<MAX_TICKS; i++)
    {
     tickStorage[i].QuadPart = (tickStorage[i].QuadPart-start.QuadPart)*1000000/frequency.QuadPart;
    }
  }
};

extern CRITICAL_SECTION cs;

extern Integer __fastcall MyThreadFunc(Pointer Parameter);
extern TEvent event;

#endif
