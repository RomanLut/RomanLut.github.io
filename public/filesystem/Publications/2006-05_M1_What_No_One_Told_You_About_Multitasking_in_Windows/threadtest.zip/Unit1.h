//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include "TMyGraph.h"
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TScrollBar *ScrollBar1;
        TMemo *Memo1;
        TButton *Button1;
        TPaintBox *PaintBox1;
        TSpeedButton *SpeedButton2;
        TSpeedButton *SpeedButton1;
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations
         bool RunTimerTest();
         void Test1();
         void Test4();
public:		// User declarations
         TMyGraph* graph;

        __fastcall TForm1(TComponent* Owner);

        void AddWorkReport(const char* prefix, __int64 done, LARGE_INTEGER start, LARGE_INTEGER end);

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
