#ifndef TMATRIX4X4_INCLUDED
#define TMATRIX4X4_INCLUDED

namespace HAXMATH
{

//===========================================================
// TMATRIX4x4
//===========================================================
class TMATRIX4x4 //COMPATIBLE WITH D3DMATRIX
{      
 public:

 float _11, _12, _13, _14;
 float _21, _22, _23, _24;
 float _31, _32, _33, _34;
 float _41, _42, _43, _44;
 
 static const TMATRIX4x4 identityMatrix;
 
 TMATRIX4x4() {;}
 
 TMATRIX4x4(const TMATRIX4x4& m) 
  {
   *this=m;
  }

 TMATRIX4x4(float _11, float _12, float _13, float _14,
           float _21, float _22, float _23, float _24,
           float _31, float _32, float _33, float _34,
           float _41, float _42, float _43, float _44)
 {
  this->_11=_11; this->_12=_12; this->_13=_13; this->_14=_14;
  this->_21=_21; this->_22=_22; this->_23=_23; this->_24=_24;
  this->_31=_31; this->_32=_32; this->_33=_33; this->_34=_34;
  this->_41=_41; this->_42=_42; this->_43=_43; this->_44=_44;
 }

 inline TMATRIX4x4 operator*(const TMATRIX4x4 &m) const
 {
  //take advantage of URVO optimization
  return TMATRIX4x4(
    _11*m._11 + _12*m._21 + _13*m._31 + _14*m._41,
    _11*m._12 + _12*m._22 + _13*m._32 + _14*m._42,
    _11*m._13 + _12*m._23 + _13*m._33 + _14*m._43,
    _11*m._14 + _12*m._24 + _13*m._34 + _14*m._44,

    _21*m._11 + _22*m._21 + _23*m._31 + _24*m._41,
    _21*m._12 + _22*m._22 + _23*m._32 + _24*m._42,
    _21*m._13 + _22*m._23 + _23*m._33 + _24*m._43,
    _21*m._14 + _22*m._24 + _23*m._34 + _24*m._44,

    _31*m._11 + _32*m._21 + _33*m._31 + _34*m._41,
    _31*m._12 + _32*m._22 + _33*m._32 + _34*m._42,
    _31*m._13 + _32*m._23 + _33*m._33 + _34*m._43,
    _31*m._14 + _32*m._24 + _33*m._34 + _34*m._44,

    _41*m._11 + _42*m._21 + _43*m._31 + _44*m._41,
    _41*m._12 + _42*m._22 + _43*m._32 + _44*m._42,
    _41*m._13 + _42*m._23 + _43*m._33 + _44*m._43,
    _41*m._14 + _42*m._24 + _43*m._34 + _44*m._44
   );
 }

 inline void SetIdentity()
  {
   *this=identityMatrix;
  }

 //classic matrix inversion
 //returns false if singular (no inversion can be found);
 bool CalculateInverceMatrix();

 TMATRIX4x4 GetInversed() const;

  //!Return determinant of a matrix.
  float Det() const;

};

} //namespace

#endif TMATRIX4X4_INCLUDED
