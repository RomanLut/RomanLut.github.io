//---------------------------------------------------------------------------


#pragma hdrstop

#include "TMyGraph.h"
#include "assert.h"

#pragma package(smart_init)

//=================================================
//=================================================
TMyGraph::TMyGraph(TPaintBox *PaintBox1, TScrollBar *ScrollBar1)
{
 this->PaintBox1=PaintBox1;
 this->ScrollBar1=ScrollBar1;

 PaintBox1->OnPaint = this->OnPaint;
 ScrollBar1->OnChange = this->OnChange;

 graphData.count = 0;

 resolution = 5000;
}

//=================================================
//=================================================
__fastcall TMyGraph::~TMyGraph()
{
 Clear();
}

//=================================================
//=================================================
void TMyGraph::Clear()
{
 for (DWORD i=0; i<graphData.count; i++)
  {
   delete[] graphData.data[i];
  }
 graphData.count = 0;
}

//=================================================
//=================================================
void TMyGraph::AddGraph(DWORD dataLength, LARGE_INTEGER* data)
{
 assert(graphData.count<MAX_GRAPHS);

 graphData.dataLength[graphData.count] = dataLength;

 graphData.data[graphData.count] = new LARGE_INTEGER[dataLength];

 memcpy(graphData.data[graphData.count], data, dataLength*sizeof(LARGE_INTEGER));

 graphData.count++;

 SetRange();
}

//=================================================
//=================================================
void TMyGraph::SetRange()
{
 LONGLONG range = 0;

 for (DWORD g =0; g<graphData.count; g++)
  {
   for (DWORD i=0; i<graphData.dataLength[g]; i++)
    {
     if (graphData.data[g][i].QuadPart>range)
      {
       range = graphData.data[g][i].QuadPart;
      }
    }
  }
 range/=resolution;
 if (range<1) range = 1;
 ScrollBar1->Max = range;
 ScrollBar1->Min = 0;
 PaintBox1->Invalidate();
}

//=================================================
//=================================================
void TMyGraph::PaintGraph(DWORD g, DWORD top, DWORD height)
{
 PaintBox1->Canvas->Pen->Color=clGreen;

 int lastx = -1;
 for (DWORD i=0; i<graphData.dataLength[g]; i++)
  {
   int x = graphData.data[g][i].QuadPart/resolution - ScrollBar1->Position;

   if (x>=PaintBox1->Width) break;
   if (x>=0 && lastx!=x)
    {
     PaintBox1->Canvas->MoveTo(x,top);
     PaintBox1->Canvas->LineTo(x,top+height);
    }
   lastx=x;
  }
 /*
 PaintBox1->Canvas->Pen->Color=clGreen;
 PaintBox1->Canvas->MoveTo(0,top+height/2);
 PaintBox1->Canvas->LineTo(PaintBox1->Width,top+height/2);

 PaintBox1->Canvas->Pen->Color=clGray;
 PaintBox1->Canvas->MoveTo(0,top+height);
 PaintBox1->Canvas->LineTo(PaintBox1->Width,top+height);
 PaintBox1->Canvas->MoveTo(0,top+height);
 PaintBox1->Canvas->LineTo(PaintBox1->Width,top+height);
 */
}



//=================================================
//=================================================
void __fastcall TMyGraph::OnPaint(System::TObject* Sender)
{
 //clear
 PaintBox1->Canvas->Brush->Color = clBlack;
 PaintBox1->Canvas->FillRect(PaintBox1->ClientRect);

 //graphs
  int h = (PaintBox1->Height-18)/MAX_GRAPHS;

 for (DWORD i=0; i<graphData.count; i++)
  {
   PaintGraph(i, h*i, h);
  }

 //ticks
 PaintBox1->Canvas->Font->Color = clWhite;

 LONGLONG time = 0;
 int left = time - ScrollBar1->Position;

 PaintBox1->Canvas->Pen->Color=clWhite;
 PaintBox1->Canvas->MoveTo(0,PaintBox1->Height-18);
 PaintBox1->Canvas->LineTo(PaintBox1->Width,PaintBox1->Height-18);

 while (left<PaintBox1->Width)
  {
   if (left>-100)
    {
     PaintBox1->Canvas->TextOut(left, PaintBox1->Height-16, FormatFloat("#.#",time/1000.0)+ "ms");
     PaintBox1->Canvas->MoveTo(left,0);
     PaintBox1->Canvas->LineTo(left,PaintBox1->Height-18);
    }
   left+=100;
   time+=100*resolution;
  }

}

//=================================================
//=================================================
void __fastcall TMyGraph::OnChange(System::TObject* Sender)
{
 PaintBox1->Invalidate();
}

//=================================================
//=================================================
void TMyGraph::SetResolution(DWORD resolution)
{
 this->resolution = resolution;
 if (resolution<1) resolution=1;
 SetRange();
}

//=================================================
//=================================================
DWORD TMyGraph::GetResolution()
{
 return resolution;
}

//---------------------------------------------------------------------------


