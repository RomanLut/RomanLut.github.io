//---------------------------------------------------------------------------


#pragma hdrstop

#include "Unit1.h"
#include "TMyGraph.h"
#include "ThreadFunc.h"
#include "tests.h"
#include "assert.h"
#include "unit2.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

//========================================================
//void Test1()
//========================================================
void Test1()
{
 TMyThreadData data;

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);

 Form1->AddWorkReport("Work done in thread:", data.workDone.QuadPart, start, end);
}

//========================================================
//void Test2()
//========================================================
void Test2()
{
 TMyThreadData data;
// TMyThreadData datax;
 TMyThreadData data2;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);
 data2.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);

 Form1->AddWorkReport("Work done in 1st thread:", data.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done in 2nd thread:", data2.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done total:", data.workDone.QuadPart+data2.workDone.QuadPart, start, end);
}

//========================================================
//void Test3()
//========================================================
void Test3()
{
 TMyThreadData data1, data2, data3, data4;

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 unsigned ThreadId1;
 unsigned ThreadId2;
 unsigned ThreadId3;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);
 HANDLE t2 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data3, 0, ThreadId2);
 HANDLE t3 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data4, 0, ThreadId3);

 MyThreadFunc(&data1);

 WaitForSingleObject(t1, INFINITE);
 WaitForSingleObject(t2, INFINITE);
 WaitForSingleObject(t3, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);
 CloseHandle(t2);
 CloseHandle(t3);

 data1.Convert(start);
 data2.Convert(start);
 data3.Convert(start);
 data4.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data1.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data3.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data4.tickStorage);

 Form1->AddWorkReport("Work done in 1st thread:", data1.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done in 2nd thread:", data2.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done in 3rd thread:", data3.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done in 4th thread:", data4.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done total:", data1.workDone.QuadPart+data2.workDone.QuadPart+
               data3.workDone.QuadPart+data4.workDone.QuadPart, start, end);

}

//========================================================
//void Test4()
//========================================================
void Test4()
{
 TMyThreadData data;
 TMyThreadData data2;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_BELOW_NORMAL);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 WaitForSingleObject(t1, INFINITE);

 CloseHandle(t1);

 data.Convert(start);
 data2.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);
}

//========================================================
//void Test5()
//========================================================
void Test5()
{
 TMyThreadData data;
 TMyThreadData data2;

 data2.callSleep0 = true;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_BELOW_NORMAL);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 WaitForSingleObject(t1, INFINITE);

 CloseHandle(t1);

 data.Convert(start);
 data2.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);
}

//========================================================
//void Test6()
//========================================================
void Test6()
{
 TMyThreadData data;
 TMyThreadData data2;

 data.callSleep0 = true;
 data2.callSleep0 = true;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 WaitForSingleObject(t1, INFINITE);

 CloseHandle(t1);

 data.Convert(start);
 data2.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);
}

//========================================================
//void Test7()
//========================================================
void Test7()
{
 TMyThreadData data;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_BELOW_NORMAL);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 DWORD t = GetTickCount();
 while (GetTickCount()-t<10000)  {;}

 WaitForSingleObject(t1, INFINITE);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
}

//========================================================
//void Test8()
//========================================================
void Test8()
{
 TMyThreadData data;
 TMyThreadData data2;

 data2.callSleep10 = true;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 WaitForSingleObject(t1, INFINITE);

 CloseHandle(t1);

 data.Convert(start);
 data2.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);
 timeBeginPeriod(0);
}

//========================================================
//void Test9()
//========================================================
void Test9()
{
 TMyThreadData data;
 TMyThreadData data2;

 data.callSleep2 = true;

 timeBeginPeriod(1);

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);
 SetThreadPriority(t1,THREAD_PRIORITY_BELOW_NORMAL);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 WaitForSingleObject(t1, INFINITE);

 CloseHandle(t1);

 data.Convert(start);
 data2.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);
 timeBeginPeriod(0);
}

typedef __cdecl (*TRun)(int, bool bWindowed, bool bCallSleep, HANDLE eventHandle, bool VSync);

//========================================================
//void Test10()
//========================================================
void Test10()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 proc(1,true,false,event.GetHandle(), Form2->cbVSync->Checked);
 FreeLibrary(DLLHandle);

 Form1->graph->Clear();
}

//========================================================
//void Test11()
//========================================================
void Test11()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 TMyThreadData data;
 data.waitForEvent=true;
 event.ResetEvent();

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_IDLE);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 proc(1,true,false,event.GetHandle(), Form2->cbVSync->Checked);

 data.bExit=true;

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);

 FreeLibrary(DLLHandle);

 Form1->AddWorkReport("Work done in thread:", data.workDone.QuadPart, data.startTime, data.exitTime);
}

//========================================================
//void Test12()
//========================================================
void Test12()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 proc(10,true,false,event.GetHandle(), Form2->cbVSync->Checked);
 FreeLibrary(DLLHandle);

 Form1->graph->Clear();
}

//========================================================
//void Test13()
//========================================================
void Test13()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 TMyThreadData data;
 data.waitForEvent=true;
 event.ResetEvent();

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_IDLE);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 proc(10,true,false,event.GetHandle(), Form2->cbVSync->Checked);

 data.bExit=true;

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);

 FreeLibrary(DLLHandle);

 Form1->AddWorkReport("Work done in thread:", data.workDone.QuadPart, data.startTime, data.exitTime);
}


//========================================================
//void Test14()
//========================================================
void Test14()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 TMyThreadData data;
 data.waitForEvent=true;
 event.ResetEvent();

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_IDLE);

//  SetThreadPriority(t1,THREAD_PRIORITY_BELOW_NORMAL);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 proc(1,false,false,event.GetHandle(), Form2->cbVSync->Checked);

 data.bExit=true;

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);

 FreeLibrary(DLLHandle);

 Form1->AddWorkReport("Work done in thread:", data.workDone.QuadPart, data.startTime, data.exitTime);
}

//========================================================
//void Test15()
//========================================================
void Test15()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 TMyThreadData data;
 data.waitForEvent=true;
 event.ResetEvent();

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_IDLE);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 proc(1,false,true,event.GetHandle(), Form2->cbVSync->Checked);

 data.bExit=true;

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);

 FreeLibrary(DLLHandle);

 Form1->AddWorkReport("Work done in thread:", data.workDone.QuadPart, data.startTime, data.exitTime);
}

//========================================================
//void Test16()
//========================================================
void Test16()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 TMyThreadData data;
 data.waitForEvent=true;
 event.ResetEvent();

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_IDLE);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 proc(10,false,true,event.GetHandle(), Form2->cbVSync->Checked);

 data.bExit=true;

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);

 FreeLibrary(DLLHandle);

 Form1->AddWorkReport("Work done in thread:", data.workDone.QuadPart, data.startTime, data.exitTime);
}

//========================================================
//void Test17()
//========================================================
void Test17()
{
 HINSTANCE DLLHandle = LoadLibrary("EnhancedMesh.dll");
 assert(DLLHandle!=0);

 TRun proc = (TRun)GetProcAddress(DLLHandle,"Run");
 assert(proc!=NULL);

 TMyThreadData data;
 data.waitForEvent=true;
 event.ResetEvent();

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 SetThreadPriority(t1,THREAD_PRIORITY_IDLE);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 proc(1,true,true,event.GetHandle(), Form2->cbVSync->Checked);

 data.bExit=true;

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);

 FreeLibrary(DLLHandle);

 Form1->AddWorkReport("Work done in thread:", data.workDone.QuadPart, data.startTime, data.exitTime);
}

//========================================================
//void Test18()
//========================================================
void Test18()
{
 TMyThreadData data;
 BYTE guard[256];
 TMyThreadData data2;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data2, 0, ThreadId1);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 MyThreadFunc(&data);

 WaitForSingleObject(t1, INFINITE);

 LARGE_INTEGER end;
 QueryPerformanceCounter(&end);

 CloseHandle(t1);

 data.Convert(start);
 data2.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
 Form1->graph->AddGraph(MAX_TICKS, data2.tickStorage);

 Form1->AddWorkReport("Work done in 1st thread:", data.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done in 2nd thread:", data2.workDone.QuadPart, start, end);
 Form1->AddWorkReport("Work done total:", data.workDone.QuadPart+data2.workDone.QuadPart, start, end);
}

//====================================
//====================================
TTestDesc TESTDESC[TESTCOUNT] =
{
 "Test 1", "Single thread with NORMAL priority.", &Test1,
 "Test 2", "Two threads with NORMAL priority.", &Test2,
 "Test 3", "Four threads with NORMAL priority.", &Test3,
 "Test 4", "One thread with NORMAL priority, one thread with BELOW_NORMAL prioprity.", &Test4,
 "Test 5", "One thread with NORMAL priority, one thread with BELOW_NORMAL prioprity. First thread calls Sleep(0).", &Test5,
 "Test 6", "Two threads with NORMAL priority. Both threads call Sleep(0).", &Test6,
 "Test 7", "Main thread with NORMAL priority, second thread with BELOW_NORMAL priority. CPU time starvation timeout detection.", &Test7,
 "Test 8", "Two threads with normal priority. Second thread calls Sleep(10) every 12 ms.", &Test8,
 "Test 9", "First thread with NORMAL priority. Second thread with BELOW_NORMAL priority. First thread calls Sleep(2) every 20ms. Using timeBeginPeriod(1).", &Test9,
 "Test 10", "Single rendering thread, low GPU load.", &Test10,
 "Test 11", "Primary rendering thread, secondary thread with IDLE priority, low GPU load.", &Test11,
 "Test 12", "Single rendering thread, GPU overloaded.", &Test12,
 "Test 13", "Primary rendering thread, secondary thread with IDLE priority, GPU overloaded.", &Test13,
 "Test 14", "Primary rendering thread, secondary thread with IDLE priority, low GPU load, fullscreen.", &Test14,
 "Test 15", "Primary thread with normal priority, background thread with IDLE priority, primary calls sleep(2) every frame to run background thread. Fulscreen. Low GPU load.", &Test15,
 "Test 16", "Primary thread with normal priority, background thread with IDLE priority, primary calls sleep(2) every frame to run background thread. Fulscreen. High GPU load.", &Test16,
 "Test 17", "Primary rendering thread, background thread with IDLE priority, primary thread calls sleep(2) every frame to run background thread. Low GPU load. Windowed.", &Test17,
 "Test 18", "Two threads with NORMAL priority. Thread local data structures separated by 256 guard bytes - for dualCore CPU. ", &Test18
};



/*
thread creation
//========================================================
//void Test8()
//========================================================
void Test8()
{
 TMyThreadData data;

 unsigned ThreadId1;

 HANDLE t1 = (HANDLE)BeginThread(NULL, 0, &MyThreadFunc, &data, 0, ThreadId1);

 LARGE_INTEGER start;
 QueryPerformanceCounter(&start);

 DWORD t = GetTickCount();
 while (GetTickCount()-t<10000)  {;}

 WaitForSingleObject(t1, INFINITE);

 CloseHandle(t1);

 data.Convert(start);

 Form1->graph->Clear();
 Form1->graph->AddGraph(MAX_TICKS, data.tickStorage);
}
*/

//test 17 -remove
