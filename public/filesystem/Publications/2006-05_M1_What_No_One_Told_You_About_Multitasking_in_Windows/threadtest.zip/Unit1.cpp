//---------------------------------------------------------------------------

#include <vcl.h>
#include <mmsystem.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "tests.h"
#include "ThreadFunc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
 InitializeCriticalSection(&cs);
 DoubleBuffered = true;
}
//---------------------------------------------------------------------------

//========================================================
//void TForm1::RunTimerTest()
//========================================================
//testing resolution of a timer.
bool TForm1::RunTimerTest()
{
 Memo1->Lines->Add("Testing timer...");

 LARGE_INTEGER frequency;
 QueryPerformanceFrequency(&frequency);

 //find miminum difference create than zero

 LONGLONG minDelta = ((LONGLONG)1) << 62;
 LONGLONG deltaSum = 0;

 for (int i=0; i<1000; i++)
  {
   LARGE_INTEGER prev;
   QueryPerformanceCounter(&prev);

   LONGLONG delta=0;

    while (delta==0)
    {
     LARGE_INTEGER curr;
     QueryPerformanceCounter(&curr);

     delta = curr.QuadPart-prev.QuadPart;
    }

   if (delta<minDelta)
    {
     minDelta=delta;
    }
   deltaSum+=delta;

  }

  Memo1->Lines->Add("Minimum difference: "+
                          String(minDelta)+
                          ", ("+
                          String((double)(minDelta)*1000/frequency.QuadPart)+
                          "ms)");

  Memo1->Lines->Add("Average difference (inacurate): "+
                          String(deltaSum/1000)+
                          ", ("+
                          String((double)(deltaSum)*1000/1000/frequency.QuadPart)+
                          " ms)");


 if (minDelta*1000/frequency.QuadPart>1)
  {
   Application->MessageBox("Resolution of timer is more than 1 ms. Unable to run tests.","Error",MB_OK);
   return false;
  }

 Memo1->Lines->Add("Timer resolution Ok.");

 return true;
}


/*
int __fastcall BeginThread(void * SecurityAttributes,
unsigned StackSize,
TThreadFunc ThreadFunc,
void * Parameter,
unsigned CreationFlags,
unsigned &ThreadId);
*/


//================================================================
//
//================================================================
void __fastcall TForm1::Button1Click(TObject *Sender)
{
 if (Form2->ShowModal()!=mrOk) return;

 Application->ProcessMessages();

 if (RunTimerTest()==false) return;

 Memo1->Lines->Add("Test start...");
 TESTDESC[Form2->ListBox1->ItemIndex].action();
 Memo1->Lines->Add("Test end.");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
 graph = new TMyGraph(PaintBox1, ScrollBar1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
 graph->SetResolution(graph->GetResolution()/2);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
 graph->SetResolution(graph->GetResolution()*2);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
 DeleteCriticalSection(&cs);
}

//---------------------------------------------------------------------------
void TForm1::AddWorkReport(const char* prefix, __int64 done, LARGE_INTEGER start, LARGE_INTEGER end)
{
 LARGE_INTEGER frequency;
 QueryPerformanceFrequency(&frequency);

 Form1->Memo1->Lines->Add(AnsiString(prefix) + AnsiString(done) +
    ", per second: "+AnsiString(done*frequency.QuadPart/(end.QuadPart-start.QuadPart)));
}
//---------------------------------------------------------------------------

