//---------------------------------------------------------------------------

#ifndef TestsH
#define TestsH
//---------------------------------------------------------------------------

//=========================
// TTestDesc
//=========================
typedef struct
{
 const char* name;
 const char* desc;
 void (*action)();
} TTestDesc;

const int TESTCOUNT = 18;

extern TTestDesc TESTDESC[TESTCOUNT];


#endif
