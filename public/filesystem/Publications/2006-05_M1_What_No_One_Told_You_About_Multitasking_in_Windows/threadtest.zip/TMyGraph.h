//---------------------------------------------------------------------------

#ifndef TMyGraphH
#define TMyGraphH

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

//---------------------------------------------------------------------------

const int MAX_GRAPHS = 4;

//========================================
//========================================
class TMyGraph : public TObject
{
 private:
  TPaintBox *PaintBox1;
  TScrollBar *ScrollBar1;

  DWORD resolution;

  struct
  {
   DWORD count;
   DWORD dataLength[MAX_GRAPHS];
   LARGE_INTEGER* data[MAX_GRAPHS];  //in microsecconds
  } graphData;

  void __fastcall OnPaint(System::TObject* Sender);
  void __fastcall OnChange(System::TObject* Sender);

  void SetRange();
  void PaintGraph(DWORD g, DWORD top, DWORD height);

 public:


 TMyGraph(TPaintBox *PaintBox1, TScrollBar *ScrollBar1);
 __fastcall ~TMyGraph();

 void Clear();
 void AddGraph(DWORD dataLength, LARGE_INTEGER* data);

 void OnPaint();
 void SetResolution(DWORD resolution);
 DWORD GetResolution();

};
#endif
