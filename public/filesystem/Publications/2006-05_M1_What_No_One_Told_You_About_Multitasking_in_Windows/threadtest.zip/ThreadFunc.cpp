//---------------------------------------------------------------------------

#include "ThreadFunc.h"

#pragma hdrstop


//---------------------------------------------------------------------------

CRITICAL_SECTION cs;
TEvent event;


//================================================================
//
//================================================================
Integer __fastcall MyThreadFunc(Pointer Parameter)
{

 LARGE_INTEGER start;
 LARGE_INTEGER prev;
 LARGE_INTEGER curr;
 LARGE_INTEGER lastSleep10;
 LARGE_INTEGER lastSleep2;

 int count = 1;

 TMyThreadData* data = (TMyThreadData*)Parameter;

 if (data->waitForEvent) event.WaitForEvent();

 if (data->fireStartingEvent) event.FireEvent();

 QueryPerformanceCounter(&start);
 prev=start;
 lastSleep10=start;
 lastSleep2=start;
 data->tickStorage[0]=prev;
 data->startTime=prev;

 while (count<MAX_TICKS)
  {
   LONGLONG delta = 0;

   if (data->callSleep0) Sleep(0);
   if (data->callSleep1) Sleep(1);

   while (delta==0)
    {
     QueryPerformanceCounter(&curr);

     delta = curr.QuadPart - prev.QuadPart;

     delta = delta*1000*100/data->frequency.QuadPart;  //10 mcs

     if (data->useCS) EnterCriticalSection(&cs);

     data->m.SetIdentity();
     data->m.CalculateInverceMatrix();
     data->workDone.QuadPart++;

     if (data->useCS) LeaveCriticalSection(&cs);
    }

   if (data->callSleep10)
    {
     if (curr.QuadPart-lastSleep10.QuadPart>data->frequency.QuadPart/1000*2)
      {
       Sleep(10);
       QueryPerformanceCounter(&lastSleep10);
      }
    }

   if (data->callSleep2)
    {
     if (curr.QuadPart-lastSleep2.QuadPart>data->frequency.QuadPart/1000*18)
      {
       Sleep(2);
       QueryPerformanceCounter(&lastSleep2);
      }
    }


//  event.FireEvent();

   data->tickStorage[count]=curr;
   count++;
   prev=curr;

   if (curr.QuadPart-start.QuadPart>data->frequency.QuadPart*10) break; //do not work more then 10 seconds

   if (data->bExit) break;

  }

 QueryPerformanceCounter(&data->exitTime);

 return 0;
}



#pragma package(smart_init)
