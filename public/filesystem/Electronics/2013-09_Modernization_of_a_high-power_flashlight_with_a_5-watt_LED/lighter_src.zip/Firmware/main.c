/*****************************************************
Lighter firmware Copyright (C) 2011 by Roman Lut
hax@deep-shadows.com
Distributed under GNU Licence.
*****************************************************/

#include <tiny26.h>

#include <stdint.h>

#include <delay.h>
#include <sleep.h>

#include <stdbool.h>

#include "stx.h"

//=============================================================================
//=============================================================================

//R13,R16 = 20.5K
//R5,R15 = 48K

//AREF voltage
#define AREF_VOLTAGE 2.5  //V

//Charge voltage and Battery voltage divider upper resistor( R15 and R5 ) 
#define SENSE_DIVIDER_UPPER     10    //kOhm    
//Charge voltage and Battery voltage divider bottom resistor( R16 and R13 ) 
#define SENSE_DIVIDER_BOTTOM    3.3   //kOhm  

//External voltage divider upper resistor( R11 ) 
#define EXTERNAL_SENSE_DIVIDER_UPPER    100     //kOhm    
//Charge voltage and Battery voltage divider bottom resistor( R12 ) 
#define EXTERNAL_SENSE_DIVIDER_BOTTOM   10      //kOhm  

//----------------------------------------
//maximum LED current 
//1.24999A MAX with AREF_VOLTAGE=.5 !!!
#define MAX_LED_CURRENT         0.9 //A

//maximum LED current while charging
#define MAX_LED_CURRENT_CHG     0.3 //A
 
#define LED_SENSE_RESISTOR      0.1 //Ohm
#define LED_SENSE_MUL           20  //ADC factor

#define LED_CURRENT_SENSE_MAX   ((uint16_t)( MAX_LED_CURRENT * LED_SENSE_RESISTOR * LED_SENSE_MUL / AREF_VOLTAGE * 1024 ))

#define LED_CURRENT_SENSE_MAX_CHG   ((uint16_t)( MAX_LED_CURRENT_CHG * LED_SENSE_RESISTOR * LED_SENSE_MUL / AREF_VOLTAGE * 1024 ))
//----------------------------------------

//----------------------------------------
#define MAX_CHARGE_CURRENT      0.6 //A
#define MIN_CHARGE_CURRENT      0.2 //A
#define CHARGE_SENSE_RESISTOR   1   //Ohm
#define CHARGE_CURRENT_DROP_MAX ((uint16_t)( MAX_CHARGE_CURRENT * CHARGE_SENSE_RESISTOR * SENSE_DIVIDER_BOTTOM / ( SENSE_DIVIDER_UPPER + SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 )) 
#define CHARGE_CURRENT_DROP_MIN ((uint16_t)( MIN_CHARGE_CURRENT * CHARGE_SENSE_RESISTOR * SENSE_DIVIDER_BOTTOM / ( SENSE_DIVIDER_UPPER + SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 )) 
//----------------------------------------

//target voltage in rapid charging mode
#define BATTERY_VOLTAGE_RAPID       ((uint16_t)( 7.35 * SENSE_DIVIDER_BOTTOM / ( SENSE_DIVIDER_UPPER + SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 ))

//rapid mode finish threshold
#define BATTERY_VOLTAGE_RAPID_DETECTED       ((uint16_t)( 7.20 * SENSE_DIVIDER_BOTTOM / ( SENSE_DIVIDER_UPPER + SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 ))

//target voltage in standby charging mode
#define BATTERY_VOLTAGE_STANDBY     ((uint16_t)( 6.8 * SENSE_DIVIDER_BOTTOM / ( SENSE_DIVIDER_UPPER + SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 ))

//battery voltage when status LED starts blinking
#define BATTERY_VOLTAGE_LOW         ((uint16_t)( 5.83 * SENSE_DIVIDER_BOTTOM / ( SENSE_DIVIDER_UPPER + SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 ))

//battery voltage when main led is disabled
#define BATTERY_VOLTAGE_MIN         ((uint16_t)( 5.8 * SENSE_DIVIDER_BOTTOM / ( SENSE_DIVIDER_UPPER + SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 ))

//minimum external voltage to start charging
#define EXTERNAL_VOLTAGE_MIN        ((uint16_t)( 7.3 * EXTERNAL_SENSE_DIVIDER_BOTTOM / ( EXTERNAL_SENSE_DIVIDER_UPPER + EXTERNAL_SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 ))

//minimum external voltage to allow raise charge current
//we limit charing current by available external power supply current
#define EXTERNAL_VOLTAGE_LOW        ((uint16_t)( 7.7 * EXTERNAL_SENSE_DIVIDER_BOTTOM / ( EXTERNAL_SENSE_DIVIDER_UPPER + EXTERNAL_SENSE_DIVIDER_BOTTOM ) / AREF_VOLTAGE * 1024 ))

//time to aim for BATTERY_VOLTAGE_RAPID after BATTERY_VOLTAGE_RAPID is achieved, 50 ticks/second 
#define RAPID_CHARGE_HOLD           ((uint16_t)( 30 * 50 )) 

//max number of ticks absorb duration can continue
//4 Hrs * 60 min * 60 sec * 50Hz
#define MAX_ABSORB_DURATION         (2 * 60 * 60 * 50)

#define LOW_VOLTAGE_DETECTION_THRESHOLD 50

//pwm * 256
uint16_t g_ledPWM;    
              
//pwm*256
uint16_t g_chargePWM;                

//0 - disabled
//1 - enabled
//2 - enabled half current
uint8_t g_LEDEnabled;

#define CM_NONE     0   //changing disabled
#define CM_RAPID    1   //rapid charging mode to achieve BATTERY_VOLTAGE_RAPID 
#define CM_ABSORB   2   //holding BATTERY_VOLTAGE_RAPID untill charge current drops less then MIN_CHARGE_CURRENT 
#define CM_STANDBY  3   //standby charging, BATTERY_VOLTAGE_STANDBY 
uint8_t g_chargingMode;   

//number of timer ticks BATTERY_VOLTAGE_RAPID is detected
uint16_t g_rapidVoltageDetected;      

//number of timer ticks BATTERY_VOLTAGE_LOW is detected
int16_t g_lowVoltageDetected;      

//number of timer ticks BATTERY_VOLTAGE_MIN is detected
int16_t g_minVoltageDetected;      

//number of timer ticks MIN_CHARGE_CURRENT is detected
int16_t g_minCurrentDetected;      

//averaged external voltage, value * 256
uint32_t g_externalVoltage = 0;  

//number of ticks absorbing charge mode is running
uint32_t g_absorbDuration;  

//======== status led =================
//status led is blinkin with period g_ledPeriod and duty cycle g_ledDuty
uint8_t g_ledPeriod = 100;
uint8_t g_ledDuty = 0;
uint8_t g_ledCounter = 0;  //50Hz
//=====================================

//generic timer counter, counting from 0 to 153 with 50Hz
volatile uint16_t g_timerCounter = 0;

//timer counter2
//used to check how many cycles pased from las time
volatile uint8_t g_timerCounter2 = 0;

//Button input state:
// 0 - released
//-1 - waiting for release
//>0 - pressed for g_buttonPressed*2 ms 
int8_t g_buttonPressed = 0;  

//=====================================================
//=====================================================
void stx_string( const flash char* _msg )
{
    while ( *_msg != 0 )
    {
        stx_char( *_msg++ );        
    } 
}

static const __flash char* hex = "0123456789ABCDEF"; 


//=====================================================
//=====================================================
void stx_uint16( uint16_t _value )
{
    stx_char( hex [ ( ( _value >> 12 ) & 0xf ) ] );
    stx_char( hex [ ( ( _value >> 8 ) & 0xf ) ] );
    stx_char( hex [ ( ( _value >> 4 ) & 0xf ) ] );
    stx_char( hex [ ( _value & 0xf ) ] );

/*
    uint16_t i = _value / 10000;
    stx_char( '0' + i );
    _value -= i * 10000; 

    i = _value / 1000;
    stx_char( '0' + i );
    _value -= i * 1000; 

    i = _value / 100;
    stx_char( '0' + i );
    _value -= i * 100; 
                                             
    i = _value / 10;
    stx_char( '0' + i );
    _value -= i * 10; 

    stx_char( '0' + _value );
    */
}

//=============================================================================
//=============================================================================
//retrive number of timer ticks passed from last call
uint8_t retriveTimerTicks()
{
    uint16_t res;
    #asm("cli")  
    
    res = g_timerCounter2;
    g_timerCounter2 = 0;

    #asm("sei")

    return res;
}

//=============================================================================
//=============================================================================
//ref=AREF
unsigned int read_adc(unsigned char adc_input)
{
ADMUX=adc_input | 0x40;
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSR|=0x40;
// Wait for the AD conversion to complete
while ((ADCSR & 0x10)==0);
ADCSR|=0x10;
return ADCW;
}

/*
//=============================================================================
//=============================================================================
//ref=AREF
unsigned int read_adc(unsigned char adc_input)
{
int res;
int i;
ADMUX=adc_input | (0x40 & 0xff);
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);

i=4;
res=0;
while ( i > 0 )
{
// Start the AD conversion
ADCSR|=0x40;
// Wait for the AD conversion to complete
while ((ADCSR & 0x10)==0);
ADCSR|=0x10;
res += ADCW;
i--;
}

return res >> 2;
}
*/



//=============================================================================
//=============================================================================
//this routine is responsible for status led on/off/blinking
void updateLed( uint8_t ticks )
{
    if ( g_ledCounter < g_ledDuty )
    {
        PORTB.6 = 1;
    }
    else
    {               
        PORTB.6 = 0;
    }

    g_ledCounter += ticks;
    if ( g_ledCounter > g_ledPeriod )
    {
        g_ledCounter = 0;
    }                  
}

//=============================================================================
//=============================================================================
//update generic timer counter
void updateTimerCounter()
{
    g_timerCounter2++;

    if ( ++g_timerCounter > 153 )
    {                     
        g_timerCounter = 0;
    }    
}                                             

//=============================================================================
//=============================================================================
//get averaged value of external voltage
//256 last values are averaged
//procedure is called with frequency 800 Hz
//-> average over 0.3 sec
uint16_t getAveragedExternalVoltage()
{
    g_externalVoltage -= g_externalVoltage >> 8;
    g_externalVoltage += read_adc( 3 );
                    
    return g_externalVoltage >> 8; 
}

//=============================================================================
//=============================================================================
//update button state
void updateButton( uint8_t ticks )
{
    if (PINB.5 == 0 )
    {  
        if ( g_buttonPressed != -1 ) //waiting for release? 
        { 
            g_buttonPressed += ticks;
        }
    }                     
    else
    {                    
        g_buttonPressed = 0;
    }  
}

//=============================================================================
//=============================================================================
void setLEDEnabled( uint8_t mode )
{
    g_ledPWM = 0;
    g_LEDEnabled = mode;        
    g_lowVoltageDetected = 0;
    g_minVoltageDetected = 0;
}

//=============================================================================
//=============================================================================
void setLEDDisabled()
{
    g_LEDEnabled = 0;        
}

//=============================================================================
//=============================================================================
uint16_t getLEDCurent()
{       
    ADMUX=0x14 | 0x40; //ADC4 - ADC5, x20
    // Delay needed for the stabilization of the ADC input voltage
    delay_us(125);
    // Start the AD conversion
    ADCSR|=0x40;
    // Wait for the AD conversion to complete
    while ((ADCSR & 0x10)==0);
    ADCSR|=0x10;
    return ADCW;
}

//=============================================================================
//=============================================================================
//Main update routine
//called with ~800Hz frequency
void update()
{
    uint16_t external_voltage;
    uint16_t charge_voltage;
    int voltage_drop;
    uint16_t battery_voltage; 
    uint16_t led_current;
    uint16_t target_voltage;
    uint16_t i,j;                   
    uint16_t target_led_current;
    uint8_t ticks;
                   
    ticks = retriveTimerTicks(); 
              
    //led blinking/on/of
    
    updateLed( ticks );
 
    updateButton( ticks );

    //get averaged value of external voltage
    external_voltage = getAveragedExternalVoltage();

    if ( g_chargingMode != CM_NONE )
    {
        if ( external_voltage < EXTERNAL_VOLTAGE_MIN )
        {
            //switch off charging mode when external voltage disconnected                                                                            
            g_chargingMode = CM_NONE;
            g_chargePWM = 0;
            PORTA.0 = 0;  //turn off relay
            setLEDEnabled( 1 );
        }
    }
    else //g_chargingMode == CM_NONE
    {              
        if ( external_voltage > EXTERNAL_VOLTAGE_MIN )
        {
            //turn on rapid charing mode if external voltage is connected
            g_chargingMode = CM_RAPID;
            g_chargePWM = 0;       
            g_rapidVoltageDetected = 0;
            PORTA.0 = 1;  //turn on relay 
            setLEDDisabled();       
        }
    }              
    
    if ( g_buttonPressed > 3 )
    { 
        g_buttonPressed = -1;
        if ( g_LEDEnabled == 2 )
        {
            if ( g_chargingMode == CM_NONE )
            {
                setLEDEnabled( 1 );
            }
            else
            {
                setLEDDisabled();
            }
        }
        else 
        {         
            setLEDEnabled( g_LEDEnabled + 1 );
        }
    }                          

    charge_voltage = read_adc( 1 ); 
    battery_voltage = read_adc( 2 ); 

    //calculate voltage drop on resistor
    //can be negative
    voltage_drop = (int)charge_voltage - (int)battery_voltage;        
    
    if ( battery_voltage >= BATTERY_VOLTAGE_RAPID_DETECTED )
    {                         
        if ( g_rapidVoltageDetected < 0xff00 )
        { 
            g_rapidVoltageDetected += ticks;
        }
    }

    //the following algoritm ensures we detect battery low state when more then 50% of
    //readings are less then low voltage. Voltage spikes should be ignored.
    if ( g_lowVoltageDetected < LOW_VOLTAGE_DETECTION_THRESHOLD )  //once detected, should stay detected untill mode chage
    { 
        if ( battery_voltage <= BATTERY_VOLTAGE_LOW )
        {                          
            g_lowVoltageDetected += ticks;
        }
        else
        {               
            g_lowVoltageDetected -= ticks;
            if ( g_lowVoltageDetected < 0 )
            {    
                g_lowVoltageDetected = 0;                    
            }
        }
    }  

    if ( battery_voltage <= BATTERY_VOLTAGE_MIN )
    {                          
        g_minVoltageDetected += ticks;
    }
    else
    {                          
        g_minVoltageDetected -= ticks;
        if ( g_minVoltageDetected < 0 )
        { 
            g_minVoltageDetected = 0;
        }
    }  
    
    if ( g_minVoltageDetected > 5*50 )
    {                    
        setLEDDisabled();
    }     

    led_current = getLEDCurent();
        
                   
    //interrupt unsafe, but ok!
    if ( g_timerCounter == 0 )
    {               
    /*
        stx_string("\n\rcm=");
        stx_uint16( g_chargingMode );
         
        stx_string("\n\rVext=");
        stx_uint16( external_voltage );

        stx_string("\n\rVchg=");
        stx_uint16( charge_voltage );
      */
        stx_string("\n\rDV=");
        stx_uint16( voltage_drop );
        stx_string("\n\rmv=");
        stx_uint16( g_minCurrentDetected );
      /*
        stx_string("\n\rIchg=");
        stx_uint16( voltage_drop );

        stx_string("\n\rLEDen=");
        stx_uint16( g_LEDEnabled );
         
        stx_string("\n\rIled=");
        stx_uint16( led_current );
        */
    } 
            
    g_absorbDuration += ticks;
        
    //-----------------------------------------------------------
    //update status led
    
    if ( g_chargingMode == CM_RAPID )
    {
        if ( g_rapidVoltageDetected > RAPID_CHARGE_HOLD )
        {                                                
            g_chargingMode = CM_ABSORB;   
            g_minCurrentDetected = 0;
            g_absorbDuration = 0;
        }

        g_ledPeriod = 50;
        g_ledDuty = 25; 
    }               
    else if ( g_chargingMode == CM_ABSORB )
    {
        if ( 
                ( g_absorbDuration > MAX_ABSORB_DURATION ) ||
                ( g_minCurrentDetected > 100*50 )
        )
        {
            g_chargingMode = CM_STANDBY;
        }

        g_ledPeriod = 200;
        g_ledDuty = 100; 
    }               
    else if ( g_chargingMode == CM_STANDBY )
    {
        g_ledPeriod = 50;
        g_ledDuty = 51; 
    }                  
    else if ( g_lowVoltageDetected >= LOW_VOLTAGE_DETECTION_THRESHOLD )
    {
        g_ledPeriod = 200;
        g_ledDuty = 50; 
    }                 
    else
    {
        g_ledDuty = 0; 
    }
    
    //-----------------------------------------------------------
        
    if ( g_chargingMode != CM_NONE  ) 
    {
        //select current target voltage
        target_voltage = BATTERY_VOLTAGE_STANDBY;
        if ( g_chargingMode != CM_STANDBY )
        {
            target_voltage = BATTERY_VOLTAGE_RAPID;
        }

        if ( voltage_drop < (int)CHARGE_CURRENT_DROP_MIN )
        {                                               
            g_minCurrentDetected += ticks;
        }                          
        else
        {
            g_minCurrentDetected -= ticks;
            if ( g_minCurrentDetected < 0 )
            { 
                g_minCurrentDetected = 0;
            }
        }
        
         
        //adjust charging current/voltage         
 
        //-------- decrease --------       
        i = 0;
        
        if ( voltage_drop > (int)CHARGE_CURRENT_DROP_MAX )
        {
            //decrease current
            i = (uint16_t)( ((int)voltage_drop) - ((int)CHARGE_CURRENT_DROP_MAX) );
            i <<= 6;       
        }              
        
        if ( battery_voltage > target_voltage )
        {                     
            //decrease voltage
            j = ( battery_voltage - target_voltage );
            j <<= 6;       

            if ( j > i ) 
            {
                i = j;
            }
        }

        if ( external_voltage < EXTERNAL_VOLTAGE_LOW )
        {                     
            //decrease voltage
            j = ( EXTERNAL_VOLTAGE_LOW - external_voltage );
            j <<= 6;       

            if ( j > i ) 
            {
                i = j;
            }
        }
        
        if ( g_chargePWM > i ) 
        {
            g_chargePWM -= i;
        }
        else
        {              
            g_chargePWM = 0;
        }                   
           
        //-------- increase --------       
        if ( i == 0 )
        {
            //increase current and voltage to reach target current/voltage
            //lower speed is selected    
            i = 0;
            if ( voltage_drop < (int)CHARGE_CURRENT_DROP_MAX )
            {                        
                //note: voltage_drop can be negative, signed arichmetic required
                i = (uint16_t)( ((int)CHARGE_CURRENT_DROP_MAX) - ((int)voltage_drop) );
                i <<= 6;
            }
             
            if ( battery_voltage < target_voltage )
            {
                j = ( target_voltage - battery_voltage );
                j <<= 6;
            
                if ( j < i ) 
                {
                     i = j;
                }
            }          

            if ( g_chargePWM < ( 0xffff - i ) ) 
            {
                g_chargePWM += i;
            }
            else
            {              
                g_chargePWM = 0xffff;
            }                   
        }                   
    }   

    OCR1B = 255 - ( g_chargePWM >> 8 );
    
    if ( g_LEDEnabled == 0 )
    {                                                       
        //low battery detected
        //disable main led
        g_ledPWM = 0;     
    }
    else
    {                              
        if ( g_chargingMode == CM_NONE  )
        {              
            target_led_current = LED_CURRENT_SENSE_MAX; 
            /*
            if ( g_LEDEnabled == 2 )
            {                                          
                target_led_current = LED_CURRENT_SENSE_MAX / 2;
            } 
            */
        }
        else
        {
            target_led_current = LED_CURRENT_SENSE_MAX_CHG; 
            /*
            if ( g_LEDEnabled == 2 )
            {                                          
                target_led_current = LED_CURRENT_SENSE_MAX_CHG / 2;
            } 
            */
        }

        if ( g_LEDEnabled == 2 )
        {                                          
           target_led_current >>= 1;
        }                              
        
        //adjust main led current
        if ( led_current > target_led_current )
        {                
            i = ( led_current - target_led_current );
            i <<= 2; //remember that led_pwm is kept * 256;
            if ( g_ledPWM > i ) 
            {
                g_ledPWM -= i;
            }
            else
            {
                g_ledPWM = 0;
            }
        }                    
        else
        {
            i = ( target_led_current - led_current );
            //i <<= 2; //remember led_current is kept * 256
            if ( g_ledPWM  < 0xffff - i ) 
            {
                g_ledPWM += i;
            }
            else
            {
                g_ledPWM = 0xffff;
            }
        }               
                       
    } 
             
    /*
    //interrupt unsafe, but ok!
    if ( g_timerCounter == 0 )
    {                           
        stx_string("\n\rCHG=");
        stx_uint16( g_chargePWM );
        stx_string(" ");
        stx_uint16( g_chargePWM >> 8 );

        stx_string("\n\rLED=");
        stx_uint16( g_ledPWM );
        stx_string(" ");
        stx_uint16( g_ledPWM >> 8 );
    } 
    */
                    
    //g_ledPWM = 0x6000;
    OCR1A = g_ledPWM >> 8;     
 }
                

//=============================================================================
//============================================================================= 
 // Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
    TCNT0= 0xff-156;  //50Hz
    updateTimerCounter();
}

//=============================================================================
//=============================================================================
void init()
{
// Crystal Oscillator division factor: 1
#pragma optsize-

#ifdef _OPTIMIZE_SIZE_
#pragma optsize+
#endif

// Input/Output Ports initialization
// Port A initialization
// Func7=Out Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=Out 
// State7=0 State6=T State5=T State4=T State3=T State2=T State1=T State0=0 
//PORTA=0x00;
DDRA=0x81;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 7,813 kHz
TCCR0=0x05;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 8000,000 kHz
// Mode: Fast PWMA & B top=OCR1C
// OC1A output: Non-Inv., /OC1A disconnected
// OC1B output: Non-Inv., /OC1B disconnected
// Timer1 Overflow Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
PLLCSR=0x00;

TCCR1A=0xF3;
TCCR1B=0x81;
TCNT1=0x00;
OCR1A=0x00;
OCR1B=0x00;
OCR1C=0xFE;

//intialize output when PWM is configured 

// Port B initialization
// Func7=In Func6=Out Func5=In Func4=Out Func3=Out Func2=In Func1=Out Func0=In 
// State7=T State6=0 State5=P State4=0 State3=0 State2=T State1=0 State0=T 
PORTB=0x20;
DDRB=0x5A;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// Interrupt on any change on pins PCINT0-7, 12-15: Off
// Interrupt on any change on pins PCINT8-11: Off
MCUCR=0x00;
GIMSK=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x02;

// Universal Serial Interface initialization
// Mode: Disabled
// Clock source: Register & Counter=no clk.
// USI Counter Overflow Interrupt: Off
USICR=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
ACSR=0x80;

// ADC initialization
// ADC Clock frequency: 125,000 kHz
// ADC Voltage Reference: AREF pin
//ADMUX=0x40;
ADCSR=0x86;

}

//=============================================================================
//=============================================================================
void main(void)
{
    g_chargePWM = 0;
    g_chargingMode = CM_NONE;

    setLEDEnabled( 1 );
        
    init();

    PORTA.0 = 0;  //turn off relay

    // Global enable interrupts
    #asm("sei")

    while (1)
    {           
        //idle();
        update();
        
        //PORTB.4 = ~PORTB.4;
    }
}
