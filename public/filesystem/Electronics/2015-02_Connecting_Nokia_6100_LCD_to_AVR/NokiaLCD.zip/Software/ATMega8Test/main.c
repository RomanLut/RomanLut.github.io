/*****************************************************
This program was produced by the
CodeWizardAVR V2.05.0 Professional
Automatic Program Generator
� Copyright 1998-2010 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 12.12.2012
Author  : 
Company : 
Comments: 


Chip type               : ATmega8
Program type            : Application
AVR Core Clock frequency: 4,000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 256
*****************************************************/

#include <mega8.h>

#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <delay.h>
#include <stdio.h>

#include "ColorLCDShield.h"

// Declare your global variables here

//================================================================
//================================================================
void main(void)
{
  char msg[128];
  uint8_t i;
// Declare your local variables here

// Declare your local variables here

// Input/Output Ports initialization
// Port B initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTB=0x00;
DDRB=0xFF;

// Port C initialization
// Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTC=0x00;
DDRC=0x00;

// Port D initialization
PORTD=0x60;
DDRD=0x8F;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 187,500 kHz
TCCR0=0x03;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 12000,000 kHz
// Mode: Fast PWM top=0x00FF
// OC1A output: Non-Inv.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x81;
TCCR1B=0x09;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
MCUCR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// USART initialization
// USART disabled
UCSRB=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC disabled
ADCSRA=0x00;

// SPI initialization
// SPI disabled
SPCR=0x00;

// TWI initialization
// TWI disabled
TWCR=0x00;

delay_ms(120);
LCDShield_init( PHILLIPS );
LCDShield_on();
LCDShield_clear( WHITE );

LCDShield_setRect(0,0,40,100, 1, ORANGE );//int x0, int y0, int x1, int y1, unsigned char fill, int color);


i = 0;

LCDShield_contrast( 63 );

        LCDShield_setChar( 65, 16, 0, 0, 0xfff );

        DDRB.1 = 0;
        
        msg[16] = 0;

while (1)
      {
      // Place your code here
        //sprintf( msg, "Variable i=%d", i );
        //i++;
        //delay_ms( 1000 );
                         
        //LCDShield_setStr( msg, 0,0, 0, RED );

        //LCDShield_setRect(100,100,110,110, 1, RED );//int x0, int y0, int x1, int y1, unsigned char fill, int color);
        //LCDShield_setRect(100,100,110,110, 1, BLUE );//int x0, int y0, int x1, int y1, unsigned char fill, int color);

//LCDShield_contrast( i );

        for ( i = 0; i < 16; i++ )
        {
            OCR1AL=i*2+20;
            DDRB.1 = 1;
            delay_ms(1);
            msg[i] = PINC.5 + '0';
            DDRB.1 = 0;
            delay_ms(0);
        }
        
      }
}
