
#define LCD_RES        0
#define CS            3 
#define DIO            1
#define SCK            2

#define    LCD_PORT_CS        PORTD
#define    LCD_PORT_SCK    PORTD
#define    LCD_PORT_RES    PORTD
#define    LCD_PORT_DIO    PORTD
