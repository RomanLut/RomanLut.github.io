#include <delay.h>
#include <stdbool.h>
#include <string.h>


/**********************************************
1234567890123456
* R      BAT LOW
    133.455 e+03
***********************************************/

static const __flash char* units[UNIT_COUNT][7] = 
    {     
        { "MOhm", "kOhm", "Ohm", "mOhm", "uOhm", "e-9", "e-12" },    
        { "e+6",  "e+3",  "F",   "mF",   "uF",   "nF",  "pF" },
        { "e+6",  "e+3",  "H",   "mH",   "uH",   "nH",  "pH" }    
    };
    
//==================================================
 /* 3-wire Serial LCD using 74HC595
Rajendra Bhatt, Sep 6, 2010
http://www.rlocman.ru/shem/schematics.html?di=67315
*/
  
// Always mention this definition statement
unsigned short Low_Nibble, High_Nibble, Mask, t, RS, Flag, temp;
 
//=============================================
//=============================================
void Delay_50us()
{
    delay_us(50);
}
 
//=============================================
//=============================================
void Write_LCD_Nibble(unsigned short N)
{
 LCD_CS( 0 );
 // ****** Write RS *********
 LCD_CLK( 0 );
 LCD_DATA( RS );
 LCD_CLK( 1 );
 LCD_CLK( 0 );
 // ****** End RS Write
 
 // Shift in 4 bits
 Mask = 8;
  for (t=0; t<4; t++)
  {
   Flag = N & Mask;
   if(Flag==0) LCD_DATA( 0 );
   else LCD_DATA( 1 );
   LCD_CLK( 1 );
   LCD_CLK( 0 );
   Mask = Mask >> 1;
  }
  // One more clock because SC and ST clks are tied
  LCD_CLK( 1 );
  LCD_CLK( 0 );
  LCD_DATA( 0 );
  LCD_CS( 1 );
  LCD_CS( 0 );
}
// ******* Write Nibble Ends
 
//=============================================
//=============================================
//Note: includes delay
 void Write_LCD_Data(unsigned short D)
 {
 RS = 1; // It is Data, not command
 Low_Nibble = D & 15;
 High_Nibble = D/16;
 Write_LCD_Nibble(High_Nibble);
 Write_LCD_Nibble(Low_Nibble);
 Delay_50us();
 }
 
//=============================================
//=============================================
//Note: correct delay should be applied after command write
void Write_LCD_Cmd(unsigned short C)
{
 RS = 0; // It is command, not data
 Low_Nibble = C & 15;
 High_Nibble = C/16;
 Write_LCD_Nibble(High_Nibble);
 Write_LCD_Nibble(Low_Nibble);
}

//======================================================
//======================================================
void LCD_Clear()
{
    Write_LCD_Cmd(0x01);  
    delay_ms( 2 );
}
 
//=============================================
//=============================================
void Initialize_LCD()
{
 Delay_50us();
 Write_LCD_Cmd(0x20); // Wake-Up Sequence
 Delay_50us();
 Write_LCD_Cmd(0x20);
 Delay_50us();
 Write_LCD_Cmd(0x20);
 Delay_50us();
 Write_LCD_Cmd(0x28); // 4-bits, 2 lines, 5x7 font
 Delay_50us();
 Write_LCD_Cmd(0x0C); // Display ON, No cursors
 Delay_50us();
 Write_LCD_Cmd(0x06); // Entry mode- Auto-increment, No Display shifting
 Delay_50us();
 LCD_Clear();
}
 
//=============================================
//=============================================
void Position_LCD(unsigned short x, unsigned short y)
{
 temp = 127 + x;
 if (y == 2) temp = temp + 64;
 Write_LCD_Cmd(temp);
 Delay_50us();
}
 
//=============================================
//=============================================
void Write_LCD_Text(const __flash char* StrData)
{
  while ( *StrData != 0)
  {               
    Write_LCD_Data( *StrData );
    StrData++;
  }
}
 
//======================================================
//======================================================
void LCD_Init()
{
    Initialize_LCD();
    Position_LCD(1,1);            
    Write_LCD_Text( "hxRLCMetter v1.2" );
    delay_ms( 1000 );
    LCD_Clear();
}

//======================================================
//======================================================
void LCD_ShowMeasurementReady()
{
    Position_LCD(1,1);
    Write_LCD_Data( '*' );
}

//======================================================
//======================================================
void LCD_HideMeasurementReady()
{
    Position_LCD(1,1);
    Write_LCD_Data( ' ' );
}

//======================================================
//======================================================
void LCD_ShowBatLow()
{
    Position_LCD(10,1);            
    Write_LCD_Text( "BAT LOW" );
}

//======================================================
//======================================================
void LCD_HideBatLow()
{
    Position_LCD(10,1);            
    Write_LCD_Text( "       " );
}

//======================================================
//======================================================
//show "Calibrating"
void LCD_ShowCalibrate()
{
    LCD_Clear();
    Position_LCD(1,2);            
    Write_LCD_Text( "CALIBRATING..." );
}

//======================================================
//======================================================
void LCD_HideCalibrate()
{
    LCD_Clear();
}

uint8_t mystrlen( const __flash char* _str )
{
    uint8_t res = 0;
    while( *_str++ != 0 )
    {
        res++;
    }
    
    return res;
}

//======================================================
//======================================================
//show number "_value / 1000"
//max is 999.999
//three fractional digits
//clear screen to the left
//show units ti the right
void LCD_ShowNumber1( uint32_t _value, const __flash char* _units )
{
    uint32_t i;
    uint8_t lead;
    
    uint8_t x = 16 - 7 - mystrlen( _units );

    Position_LCD(1,2);
    
    while ( x > 1 )
    {                     
        Write_LCD_Data( ' ' );
        x--;
    }
    
    lead = 0;
    
    if ( _value > 999999 )
    {
        _value = 999999;
    }
                        
    i = _value / 100000;
    _value -= i * 100000;
    if( i != 0 )
    { 
        Write_LCD_Data( '0' + ((uint8_t)i) );
        lead = 1;
    }
    else
    {
        Write_LCD_Data( ' ' );
    }
    
    i = _value / 10000;
    _value -= i * 10000;
    if( (i+lead) != 0 )
    { 
        Write_LCD_Data( '0' + ((uint8_t)i) );
        lead = 1;
    }
    else
    {
        Write_LCD_Data( ' ' );
    }

    i = _value / 1000;
    _value -= i * 1000;
    if( (i+lead) != 0 )
    { 
        Write_LCD_Data( '0' + ((uint8_t)i) );
        //lead = 1;
    }
    else
    {
        Write_LCD_Data( ' ' );
    }

    Write_LCD_Data( '.' );

    i = _value / 100;
    _value -= i * 100;
     Write_LCD_Data( '0' + ((uint8_t)i) );

    i = _value / 10;
    _value -= i * 10;
     Write_LCD_Data( '0' + ((uint8_t)i) );

     Write_LCD_Data( '0' + ((uint8_t)i) );
     
    Write_LCD_Data( ' ' );
    
    Write_LCD_Text( _units );     
}

/*
//======================================================
//======================================================
//show number at position 2 (digits 5,6,7)
//assuming _value is number
//-99..99 
void LCD_ShowNumber2( int8_t _value )
{
    uint8_t i;
    Position_LCD(13,2);

     Write_LCD_Data( 'e' );
     
    if ( _value < 0 )
    {         
        Write_LCD_Data( '-' );
        _value = -_value;
    }   
    else
    {
        Write_LCD_Data( '+' );
    } 

    if ( _value > 99 )
    {
        _value = 99;
    }
    
    i = _value / 10;
    _value -= i * 10;
     Write_LCD_Data( '0' + ((uint8_t)i) );

     Write_LCD_Data( '0' + ((uint8_t)_value) );
}
*/

//======================================================
//======================================================
void LCD_ShowNumber( float _value, float _ofs, uint8_t _units )
{
    //show number in e6/e3/-/e-3/e-6/e-9/e-12 form
    //mantissa is shown in units, see units[][]
    //minimum is 0.1e12  
    float m;
    
    if ( _value >= 1e6 )
    {            
        if ( _value >= 999 * 1e6 )
        {    
            _value = 999 * 1e6;
        }           

        m = _value / 1e6;
        LCD_ShowNumber1( m * 1000, units[ _units ][ 0 ] );  
    }
    else if ( _value >= 1e3 )
    {            
        m = _value / 1e3;
        LCD_ShowNumber1( m * 1000, units[ _units ][ 1 ] );
    }
    else if ( _value >= _ofs )
    {            
        m = _value;
        LCD_ShowNumber1( m * 1000, units[ _units ][ 2 ]  );
    }                    
    else if ( _value >= 1e-3 )
    {            
        m = _value * 1e3;
        LCD_ShowNumber1( m * 1000, units[ _units ][ 3 ]  );
    }                    
    else if ( _value >= 1e-6 )
    {            
        m = _value * 1e6;
        LCD_ShowNumber1( m * 1000, units[ _units ][ 4 ]  );
   }                    
    else if ( _value >= 1e-9 )
    {            
        m = _value * 1e9;
        LCD_ShowNumber1( m * 1000, units[ _units ][ 5 ]  );
    }                    
    else if ( _value >= 1e-13 )
    {            
        m = _value * 1e12;     
        LCD_ShowNumber1( m * 1000, units[ _units ][ 6 ]  );
    }
    else
    {
        Position_LCD(1,2);
        Write_LCD_Text( "               0" );
    }                    
}

//======================================================
//======================================================
void LCD_ShowMode( const __flash char* _mode )
{
        Position_LCD(3,1);
        Write_LCD_Text( _mode );
}
