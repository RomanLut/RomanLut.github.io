//This file contains definitions for resistors/capacitors used in actual schematics

//Precise value for R22, Ohm * 10, f.e. 97.2 Ohm -> 972
#define RCAL1_VAL       1000 //1000

//Precise value for R23, Ohm
#define RCAL2_VAL       10000 //10000

//Precise value for R24, Ohm
#define RCAL3_VAL       100000  //100000

//Precise value for R25, Ohm
#define RCAL4_VAL       1000000 //1000000


//Precise value for C4, Farades
#define CCAL            0.000000001  //0.000000001

//calibration resistors for ESR calibartion, Ohm
flash const float s_ESR_CAL_R[ ESR_CAL_COUNT ] = { 0, 0.05, 0.1, 0.2, 0.33, 0.6, 1.0, 2.2, 3.6,  4.7, 6.6, 10.0 }; 


