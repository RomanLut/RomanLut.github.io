#include "LCD_Impl.h"

//define to use HD44780 LCD
#define USE_HD44780

//====================================
extern void LCD_CS( uint8_t val  );
extern void LCD_DATA( uint8_t val );
extern void LCD_CLK( uint8_t val );
//====================================

#ifdef USE_HD44780
#include "lcd_HD44780.inc.c"
#else
#include "lcd_d7225.inc.c"
#endif
