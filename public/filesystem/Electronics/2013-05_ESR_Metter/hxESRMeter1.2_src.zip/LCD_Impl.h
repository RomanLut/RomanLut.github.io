#ifndef LCD_IMPL_INCLUDED
#define LCD_IMPL_INCLUDED

#include <stdint.h>

//==========================
#define UNIT_OHMS       0
#define UNIT_FARADES    1
#define UNIT_HENRYS     2
#define UNIT_COUNT      3

//Init LCD
extern void LCD_Init();

//show/hide "Measurement ready" indicator
extern void LCD_ShowMeasurementReady();
extern void LCD_HideMeasurementReady();

//show/hide "Batery low" indicator
extern void LCD_ShowBatLow();
extern void LCD_HideBatLow();

//show "Calibrating"
extern void LCD_ShowCalibrate();
//hide "Calibrating"
extern void LCD_HideCalibrate();

//clear screen
extern void LCD_Clear();

//show float number
//values less then 1e3 and greater than _ofs will be shown as plain number ( no exponent )
//values less than _ofs will have mantissa ( f.e. 3.500 e-03 ).
//units are UNIT_XXX
extern void LCD_ShowNumber( float _value, float _ofs, uint8_t _units );

//show current mode:
//"R  "
//"C  "
//"L  "
//"ESR"
extern void LCD_ShowMode( const __flash char* _mode );

#endif LCD_IMPL_INCLUDED
