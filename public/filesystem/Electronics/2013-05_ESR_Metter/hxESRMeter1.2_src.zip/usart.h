#ifndef USART_INCLUDED
#define USART_INCLUDED

#include <stdint.h>
#include <stdbool.h>

extern void USART_TransmitChar( unsigned char data );
extern void USART_TransmitBuf( unsigned const char* data, int data_len );
extern bool USART_HasData();
extern unsigned char USART_ReceiveChar();
extern void USART_sprintf( flash unsigned const char* fmt, ... );


#endif USART_INCLUDED
