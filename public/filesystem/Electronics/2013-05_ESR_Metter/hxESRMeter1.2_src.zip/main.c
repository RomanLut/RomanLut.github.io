/*****************************************************
hxRLCMetter v1.2
Copyright (C) by Roman Lut
http://www.deep-shadows.com/hax/
This program is Freeware

Chip type               : ATMega8
AVR Core Clock frequency: 4,000000 MHz
*****************************************************
V1.2
- fixed resistance calculation
- added HD44780 support
- components values are moved to components.h

*****************************************************/

#include <mega8.h>

#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <delay.h>
#include <stdio.h>

#include "LCD_Impl.h"
#include "usart.h"

//number of ESR calibration resistors + 1
#define ESR_CAL_COUNT 12

#include "components.h"

//====================================================================
//====================================================================

#define LCD_CS_PORT     PORTD.2
#define LCD_DATA_PORT   PORTD.3 
#define LCD_CLK_PORT    PORTD.4

#define POWER_HOLD      PORTB.4
#define C1EN            PORTB.0

//#define LC              PORTB.0
#define OUT_M_C         PORTB.2  //if 1, C mode is selected
#define IN_M_C          PINB.2  //if 1, C mode is selected
#define OUT_M_NR        PORTB.1  //if 0, R mode is selected
#define IN_M_NR         PINB.1  //if 0, R mode is selected
#define OUT_M_NESR      PORTB.5 //if 0, ESR mode is selected
#define IN_M_NESR       PINB.5 //if 0, ESR mode is selected

#define MODE_ESR    0
#define MODE_C      1
#define MODE_L      2
#define MODE_R      3
#define MODE_NONE   4 

//max idle time before turn off
#define MAX_IDLE  ( 62500 * 60 * 5 )

//max working time before turn off
#define MAX_WORKING  ( 62500 * 60 * 15 )

//number of generator ticks to count (LC metter)
#define AP_COUNT        1000

//number of ticks after which algorithm has to use source ticks counted so far (LC Metter)
#define AP_THRESHOLD    1000000

//resistance of open 2N7002 transistor at t=25C, Ohm * 10, f.e 1.7Ohm = 17
#define RCAL_RDSON      17

#define RCAL1           PORTC.1
#define RCAL2           PORTC.2

#define RCAL3           PORTC.3
#define IN_RCAL3        PINC.3
#define DDR_RCAL3       DDRC.3

#define RCAL4           PORTD.6
#define IN_RCAL4        PIND.6
#define DDR_RCAL4       DDRD.6

//known L
//#define LCAL            ( 47e-6 )

//Timer 0 frequency
#define CLOCK_FREQ      62500 

//PI
#define PI              3.14159265

#define R_ADC           0

#define ESR1_ADC        4
#define ESR2_ADC        5

//====================================================================
//====================================================================

//incremented on T0 overflow
volatile uint32_t s_t0counter = 0;

//incremented on T1 overflow
volatile uint16_t s_t1counter = 0;

//last operation mode
unsigned char s_lastMode = MODE_NONE;

//number of ticks for C1 only, or number of ticks for Rcal
eeprom float s_N0;

//number of ticks for C1+Ccal
eeprom float s_N1;

//timer 1 counter value
uint32_t s_lastIdle;

//gain of ESR2 input relative to ESR1 input
//gain1 = 3
//gain2 = 21
#define ESR2_MUL    7

//zero point for ESR1 ADC
eeprom uint16_t s_ESR1_Zero;

//zero point for ESR2 ADC
eeprom uint16_t s_ESR2_Zero;

//maximum output voltage of lm358 amplifier  3.75V / 5V * 1024
//take a little bit lower value for safety
#define ESR_ADC_MAX   730

//ESR metter calibrate points (measured ESR ADC value above zero point )
//0.1Ohm, 0.2Ohm, 0.3Ohm, 0.6Ohm, 1Ohm, 3.3Ohm, 10Ohms
eeprom uint16_t s_ESR_ADC_CAL[ ESR_CAL_COUNT ] = { 0, 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000 };


//keep rcal in array
flash const int32_t rcal[ 4 ] = { RCAL1_VAL, RCAL2_VAL, RCAL3_VAL, RCAL4_VAL };

//calibrated zero value for ESR
eeprom float s_R_Zero;

//low power detected once
bool s_bLowPower = false;

//0 - after power off, ignore press
//1 - check for power off
//uint8_t s_powerOffState = 0;
 
//====================================================================
//====================================================================
// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
    s_t0counter++;
}

//====================================================================
//====================================================================
// Timer1 overflow interrupt service routine
interrupt [TIM1_OVF] void timer1_ovf_isr(void)
{
    s_t1counter++;
}

//======================================================
//======================================================
void LCD_CS( uint8_t val )
{
    LCD_CS_PORT = val;
}

//======================================================
//======================================================
void LCD_DATA( uint8_t val )
{
    LCD_DATA_PORT = val; 
}

//======================================================
//======================================================
void LCD_CLK( uint8_t val )
{
    LCD_CLK_PORT = val;
}

//====================================================================
//====================================================================
//return timer 0 counter 
//system clock counting, 62500Hz, freq  /64
uint32_t getTimer0Counter() 
{
    uint32_t res;
    uint8_t check;
       
    while ( true )
    {      
        check = TCNT0;        
        #asm("cli")
        res = s_t0counter;
        #asm("sei")         
          
        res <<= 8;
        res += check;

        if ( check < TCNT0 )
        {
            break;
        }
    }    
    
    return res;
}

//====================================================================
//====================================================================
//return timer 1 counter  
//T1 rising edge
uint32_t getTimer1Counter() 
{
    uint32_t res;
    uint16_t check;
       
    while ( true )
    {        
        check = TCNT1;        
        #asm("cli")
        res = s_t1counter;
        #asm("sei")         
          
        res <<= 16;
        res += check;

        if ( check < TCNT1 )
        {
            break;
        }
    }    
    
    return res;
}

//====================================================================
//====================================================================
//return current mode,sensed from bits
unsigned char getMode()
{
    if ( IN_M_NESR == 0 )
    {
        return MODE_ESR;
    }                 
    else if ( IN_M_C != 0 )
    {
        return MODE_C;
    }                 
    else if ( IN_M_NR == 0 )
    {
        return MODE_R;
    }
    else
    {
        return MODE_L;
    }
}

//====================================================================
//====================================================================
//return current mode, with anti-jittering
unsigned char getModeStable()
{
    unsigned char res;
    unsigned int i;

    OUT_M_NESR = 1;  
    OUT_M_C = 1;     
    OUT_M_NR = 0;
                    
    while ( true )
    {
        res = getMode();
        
        for ( i = 0; i < 100; i++ )
        {                
            delay_ms( 1 );
            if ( res != getMode() )
            {
                goto l1;
            };
        };
        
        OUT_M_NESR = 0;  
        OUT_M_C = 0;     
        OUT_M_NR = 0;

        return res;
        l1:;
    }
}

//====================================================================
//====================================================================
//return true if "Set zero" button is pressed
bool checkSetZero() 
{
    DDR_RCAL4 = 0;
    RCAL4 = 1;
    
    if ( IN_RCAL4 == 0 )
    {
        delay_ms( 10 );
        if ( IN_RCAL4 == 0 )
        {
            LCD_ShowCalibrate();

            while ( IN_RCAL4 == 0 )
            {
                delay_ms( 10 );
            }            

            RCAL4 = 0;
            DDR_RCAL4 = 1;
             
            delay_ms( 100 );
            
            return true;                        
        }
    }
    
    RCAL4 = 0;
    DDR_RCAL4 = 1;
    return false;
}

//====================================================================
//====================================================================
void powerOff()
{
    POWER_HOLD = 1;
    while ( true ) {;}
}

//====================================================================
//====================================================================
//return true if "Power" button is pressed
void checkPowerOff() 
{
    DDR_RCAL3 = 0;
    RCAL3 = 1;
    
    if ( IN_RCAL3 == 0 )
    {       
        delay_ms( 10 );
        if ( IN_RCAL3 == 0 )
        {                      
            LCD_Clear();
            
            while ( IN_RCAL3 == 0 )
            {
                delay_ms( 10 );
            }            

            delay_ms( 100 );
                  
            powerOff();                        
        }
    }
    
    RCAL3 = 0;
    DDR_RCAL3 = 1;
}

//AVCC VREF
#define ADC_VREF_TYPE 0x40
//====================================================================
//====================================================================
void prepareADC( uint8_t adc_input )
{
    ADMUX = adc_input | ( ADC_VREF_TYPE & 0xff );
    // Delay needed for the stabilization of the ADC input voltage
    delay_ms( 1 );
}

//====================================================================
//====================================================================
void checkLowPower()
{
    if ( getTimer0Counter() < CLOCK_FREQ * 5 )
    {
        return;
    } 
                   
    if ( ( ACSR & 0x20 ) != 0 )
    {
        s_bLowPower = true;
    }                     
    
    if ( s_bLowPower )
    {
        LCD_ShowBatLow();
    }    
}

//====================================================================
//====================================================================
void configureHardware()
{
// Input/Output Ports initialization
// Port B initialization
// Func7=In Func6=In Func5=In Func4=Out Func3=Out Func2=In Func1=In Func0=Out 
// State7=T State6=T State5=T State4=P State3=T State2=T State1=T State0=T 
PORTB=0x11;
DDRB=0x19;

// Port C initialization
// Func6=In Func5=In Func4=In Func3=Out Func2=Out Func1=Out Func0=In 
// State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTC=0x00;
DDRC=0x0E;

// Port D initialization
// Func7=In Func6=Out Func5=In Func4=Out Func3=Out Func2=Out Func1=In Func0=In 
// State7=T State6=T State5=T State4=1 State3=1 State2=1 State1=T State0=T 
PORTD=0x1c;
DDRD=0x5C;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 62,500 kHz
TCCR0=0x03;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: T1 pin Rising Edge
// Mode: Normal top=0xFFFF
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: On
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x00;
TCCR1B=0x07;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: 4000,000 kHz
// Mode: CTC top=OCR2
// OC2 output: Toggle on compare match
ASSR=0x00;
TCCR2=0x09; //19 to connect output
TCNT2=0x00;
OCR2=20;  //100Khz

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
MCUCR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x05;

// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 9600
UCSRA=0x00;
UCSRB=0x18;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x19;

// Analog Comparator initialization
// Analog Comparator: On
// The Analog Comparator's positive input is
// connected to the Bandgap Voltage Reference
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x40;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 62,500 kHz
// ADC Voltage Reference: Int., cap. on AREF
ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0x86;

// SPI initialization
// SPI disabled
SPCR=0x00;

// TWI initialization
// TWI disabled
TWCR=0x00;
}

//====================================================================
//====================================================================
void disableCCal()
{
    C1EN=0;
    DDRC.5 = 0;
}

//====================================================================
//====================================================================
void enableCCal()
{
    C1EN=1;
    DDRC.5 = 1;
}

//====================================================================
//====================================================================
void disableOCR2()
{
    TCCR2=0x09;
}

//====================================================================
//====================================================================
void enableOCR2()
{
    TCCR2=0x19;
}


//====================================================================
//====================================================================
//return number of T1 ticks counted during AP_Count ticks
//T1 frequency = result * TIMER_FREQ/AP_COUNT
float countLC()
{
    uint32_t t0Start;
    uint32_t t1Start;
    uint32_t t0;
    uint32_t t1;
    float res;
    
    //char buf[100];
    
    t0Start = getTimer0Counter();
    t1Start = getTimer1Counter();
  
    //count T1 ticks during AP_COUNT generator ticks
    //break if number of T1 ticks > AP_THRESHOLD  
    while ( true )
    {            
        t0 = getTimer0Counter();
        t1 = getTimer1Counter();

        t0 -= t0Start;
        t1 -= t1Start;

        if ( t0 >= AP_COUNT )
        {
            break;
        }

        if ( t1 >= AP_THRESHOLD )
        {
            break;
        }
    }            
    
    if ( t0 == 0 )
    {
        return 0;
    }       
    
    //sprintf( buf, "timer=0%u8,s=%8u,t0=%8u\r\nt1=%8u\r\n\n", getTimer0Counter(),t0Start, t0, t1 );
    //USART_TransmitBuf( buf, strlen( buf ));
    
    res = AP_COUNT * 1.0 / t0;
    return res * t1;    
}

//====================================================================
//====================================================================
// Read the AD conversion result
unsigned int readADC()
{
    // Start the AD conversion
    ADCSRA|=0x40;
    // Wait for the AD conversion to complete
    while ((ADCSRA & 0x10)==0);
    ADCSRA|=0x10;
    return ADCW;
}

//====================================================================
//====================================================================
//returns sum of 16 measurements
unsigned int readADC16_Sum()
{
    unsigned int res = 0;
    uint8_t i;
    
    for ( i = 0; i < 16; i++ )
    {
        res += readADC();
    } 

    return res;
}

//====================================================================
//====================================================================
//return average value of 16 measurements
unsigned int readADC16_Avg()
{
    unsigned int res = readADC16_Sum();
    res += 8; //add 8 for correct rounding: f.e 143.6 -> 144.    
    return res >> 4;
}

//====================================================================
//====================================================================
//calibrate LC metter
void calibrateLC()
{
    disableCCal();
    delay_ms( 500 );
    s_N0 = countLC();
    
    enableCCal();
    delay_ms( 500 );
    s_N1 = countLC();
    
    disableCCal();
}

//====================================================================
//====================================================================
void prepareMode()
{
    if ( s_lastMode == MODE_C )                       
    {
        LCD_ShowCalibrate();
        calibrateLC();
        LCD_HideCalibrate();
    }
    else
    {     
        disableCCal();                  
        LCD_ShowCalibrate();
        delay_ms( 1000 );
        LCD_HideCalibrate();
    }
}

//====================================================================
//====================================================================
void resetIdle()
{
    s_lastIdle = getTimer0Counter();
}

//====================================================================
//====================================================================
void measureR()
{
    uint16_t val[ 4 ];

    uint8_t i; 
    uint32_t res, res1, res2, er, f2;
    uint16_t f;
    float fres;            
    
    RCAL1 = 0;
    RCAL2 = 0;
    RCAL3 = 0;
    RCAL4 = 0;

    prepareADC( R_ADC );             
    
    //measure voltage on each RCAL 

    RCAL1 = 1;
    delay_ms(50);
    val[0] = readADC16_Avg(); 
    RCAL1 = 0;

    RCAL2 = 1;
    delay_ms(50);
    val[1] = readADC16_Avg(); 
    RCAL2 = 0;

    RCAL3 = 1;
    delay_ms(50);
    val[2] = readADC16_Avg(); 
    RCAL3 = 0;

    RCAL4 = 1;
    delay_ms(200);
    val[3] = readADC16_Avg(); 
    RCAL4 = 0;

    USART_sprintf( "MODER: val: %d,%d,%d,%d,z*1024:%li\n\r", val[0], val[1], val[2], val[3], (int32_t)(s_R_Zero * 1024) );

    res = 3000000*10;
    er = 10000000;   
                      
    //( RCal + RdsOn ) * Uall /Ux - RCal - RdsOn - R100
    //x10 => ( RCal + RdsOn) * Uall /Ux * 10 - ( RCal - RdsOn - R100 ) * 10
                
    for ( i = 0; i < 4; i++ )
    {              
        f = val[ i ]; //f = Ux, 0..1023
        if ( ( f > 10 ) && ( f < 1010 ) )
        {                           
            f2 = rcal[ i ] + RCAL_RDSON;  //(RCal + RDSOn) * 10  ( Ohm ) 
            res1 = f2 * 1024;   //res = ( RCall + RdsOn ) * 10 * Uall(1024 ADC Steps)
            res2 = res1;
            res1 /= f;   // ( RCal + RdsOn )*10 * Uall(1024 ADC Steps) / [ Ux (ADC Steps) ] = ( RCal + RdsOn )*10 * UAll / Ux 
            res2 /= ( f + 1 );  //( RCal + RdsOn )*10 * Uall(1024 ADC Steps) / [ Ux (ADC Steps) + 1 ADC Step ] = ( RCal + RdsOn )*10 * UAll / Ux with 1 ADC Step error

            res2 = res1 - res2;  //1 ADC step error

            f2 = ( f2 + 900 ); //(RCal + RDSOn) * 10 + R100 * 10
                                //we take R100 (R21 on schematics) as 90 Ohm to allow small 
                                //errors due to zero level low precision/temperature drift
            if ( res1 > f2 )
            {
                res1 -= f2; //( RCal + RdsOn )*10 * UAll / Ux - [ (RCal + RDSOn) * 10 + R100 * 10 ] 
            }              
            else
            {
                res1 = 0;
            }            

            USART_sprintf( "%d - %li, %li - ", i, res1 / 10, res2 / 10 );
            
            if ( er > res2 )
            {
                USART_sprintf( "taken\n\r" );
                
                res = res1;
                er = res2;
            }                       
            else
            {
                USART_sprintf( "skipped\n\r" );
            }                        
        }
        else
        {
            USART_sprintf( "%d - skipped\n\r", i );
        } 
    }    
    
    if ( res < ( 3000000*10 ) )
    {
        fres = res / 10.0;
        
        if ( checkSetZero() )
        {
            s_R_Zero = fres; 

            delay_ms( 1000 );
            LCD_HideCalibrate();
        }

        if ( fres > s_R_Zero )
        {
            fres -= s_R_Zero;  
        }
        else
        {
            fres = 0;  
        }
                              
        //round to 0.1
        /*
        fres *= 10;
        fres = ( uint32_t )( fres + 0.5 );
        fres /= 10;
        */
        LCD_ShowNumber( fres, 0.0099, UNIT_OHMS );  
                        
        resetIdle();
    }
    else
    {
        LCD_ShowNumber( 0, 1, UNIT_OHMS );
    }
}

//====================================================================
//====================================================================
void measureL()
{
    float f;
    float f1;
    float f2;                 
    float f3;
    float f4;
             
    disableCCal();

    f = countLC();
    f4 = f;
    f += 1e-6;
             
    
    f3 = ( 2 * PI * s_N0 * CLOCK_FREQ / AP_COUNT );
    f3 = f3 * f3;
    f3 = f3 * CCAL;  

    f1 = s_N0 / f;
    f1 = f1 * f1 - 1;
    
    f2 = s_N0 / s_N1;
    f2 = f2 * f2 - 1;
    
    f = f1 * f2 / f3;
    
    
    
    //f = s_N0*s_N0*LCAL / ( f*f );
    USART_sprintf( "MODEL: s_N0=%li\r\ns_n1=%li\r\nf=%li\r\nres*10e9=%li\r\n\n",(uint32_t)s_N0, (uint32_t)s_N1, (uint32_t)f4, (uint32_t)(f*1e9) );

    if ( ( f < 1e-10 ) || ( f > 1e-1 ) )
    {
        LCD_ShowNumber( 0, 1, UNIT_HENRYS );
    }          
    else
    {
        LCD_ShowNumber( f, 1, UNIT_HENRYS );
        resetIdle();
    }
}

//====================================================================
//====================================================================
void measureC()
{
    float f;
    float f3;
    float f1;
    float f2;
    
    if ( checkSetZero() )
    {
        calibrateLC();

        delay_ms( 1000 );
        LCD_HideCalibrate();
        return;
    }
    
    f = countLC();
    f3 = f;             
    
    f += 1e-6;
            
    f1 = s_N0/f;
    f1 = f1 * f1 - 1;
    
    f2 = s_N0 / s_N1;
    f2 = f2 * f2 - 1;
    
    f = f1 / f2 * CCAL;
    
    USART_sprintf( "MODEC: s_N0=%li\r\ns_n1=%li\r\nf=%li\r\nres*10e12=%li\r\n\n", (uint32_t)s_N0, (uint32_t)s_N1, (uint32_t)f3,(uint32_t)(f*1e12) );
    
    if ( f < 7e-13 )
    {
        LCD_ShowNumber( 0, 1, UNIT_FARADES );
    }
    else
    {          
        LCD_ShowNumber( f, 1, UNIT_FARADES );
        resetIdle();
    }
}

//====================================================================
//====================================================================
//_esr_adc_val - value from getESRADC()
//returns 99 for out of range resistance
float ESRInterpolate( uint16_t _esr_adc_val )  //linear interplation
{
    uint8_t i;
    float d;
    for ( i = 1; i < ESR_CAL_COUNT; i++ )
    {
        d = s_ESR_ADC_CAL[ i ] - s_ESR_ADC_CAL[ i - 1 ] ;
        if ( d < 1 )
        {
            d = 1;
        }

        if ( _esr_adc_val < s_ESR_ADC_CAL[ i ] )
        {
        
            return ( s_ESR_CAL_R[ i ] - s_ESR_CAL_R[ i - 1 ] ) / d * ( _esr_adc_val - s_ESR_ADC_CAL[ i - 1 ] ) +  s_ESR_CAL_R[ i - 1 ];
        }           
    }                                     

    //note: d for i = ESR_CAL_COUNT-1 is calculated in cycle    
    //extrapolate + 10%
    d = ( s_ESR_CAL_R[ ESR_CAL_COUNT - 1 ] - s_ESR_CAL_R[ ESR_CAL_COUNT - 2 ] ) / d * ( _esr_adc_val - s_ESR_ADC_CAL[ ESR_CAL_COUNT - 2 ] ) +  s_ESR_CAL_R[ ESR_CAL_COUNT - 2 ];    
    
    if ( d < s_ESR_CAL_R[ ESR_CAL_COUNT - 1 ] * 1.1 )
    {
        return d;
    }
    else
    {
        return 99;
    }
}

/*
//====================================================================
//====================================================================
//_esr_adc_val - value from getESRADC()
//returns 99 for out of range resistance
float ESRInterpolate( uint16_t _esr_adc_val ) //cubic spline interpolation
{
    uint8_t i;
    float A, B, C, F, h_i, h_i1, z;

    float splineB[ ESR_CAL_COUNT ];
    float splineC[ ESR_CAL_COUNT ];
    float splineD[ ESR_CAL_COUNT ];
    float alpha[ ESR_CAL_COUNT - 1 ];
    float beta[ ESR_CAL_COUNT - 1 ];

//  splines[i].x = x[i];
//  splines[i].a = y[i];
              
    splineC[ 0 ] = 0;

    alpha[0] = beta[0] = 0.;
    for ( i = 1; i < ESR_CAL_COUNT - 1; ++i )
    {
        h_i = s_ESR_ADC_CAL[i] - s_ESR_ADC_CAL[i - 1]; 
        h_i1 = s_ESR_ADC_CAL[i + 1] - s_ESR_ADC_CAL[i];
        A = h_i;
        C = 2. * (h_i + h_i1);
        B = h_i1;
        F = 6. * ((s_ESR_CAL_R[i + 1] - s_ESR_CAL_R[i]) / h_i1 - (s_ESR_CAL_R[i] - s_ESR_CAL_R[i - 1]) / h_i);
        z = (A * alpha[i - 1] + C);
        alpha[i] = -B / z;
        beta[i] = (F - A * beta[i - 1]) / z;
    }
 
    splineC[ ESR_CAL_COUNT - 1 ] = (F - A * beta[ESR_CAL_COUNT - 2]) / (C + A * alpha[ESR_CAL_COUNT - 2]);
 
    for ( i = ESR_CAL_COUNT - 2; i > 0; --i )
    {
        splineC[i] = alpha[i] * splineC[i + 1] + beta[i];
    }
 
    for ( i = ESR_CAL_COUNT - 1; i > 0; --i )
    {
        h_i = s_ESR_ADC_CAL[i] - s_ESR_ADC_CAL[i - 1];
        splineD[i] = (splineC[i] - splineC[i - 1]) / h_i;
        splineC[i] = h_i * (2. * splineC[i] + splineC[i - 1]) / 6. + (s_ESR_CAL_R[i] - s_ESR_CAL_R[i - 1]) / h_i;
    }
}
*/

//====================================================================
//====================================================================
//returns 32767 in _pVal for out of range values 
void GetESRADC( uint16_t* _pESR1Val, uint16_t* _pESR2Val, uint16_t* _pVal  )
{
    //note: function should handle invalid values gracefully before calibrated
    
    prepareADC( ESR1_ADC );
    delay_ms( 50 );
    *_pESR1Val = readADC16_Avg(); 

    prepareADC( ESR2_ADC );
    delay_ms( 50 );
    *_pESR2Val = readADC16_Avg();    
    
    if ( *_pESR2Val < ESR_ADC_MAX )
    {             
        if ( *_pESR2Val > s_ESR2_Zero )
        {
            *_pVal = *_pESR2Val - s_ESR2_Zero; 
        }
        else
        {
            *_pVal = 0;
        } 
    }
    else if ( *_pESR1Val < ESR_ADC_MAX )
    {
        if ( *_pESR1Val > s_ESR1_Zero )
        {
            *_pVal = *_pESR1Val - s_ESR1_Zero; 
        }
        else
        {
            *_pVal = 0;
        }             
        
        *_pVal *= ESR2_MUL;
    }
    else
    {
        *_pVal = 32767;
    }  
}


//====================================================================
//====================================================================
void measureESR()
{
    float f;
    uint16_t ESR1Val, ESR2Val, ESRVal;
    
    enableOCR2();
    delay_ms( 200 );
              
    GetESRADC( &ESR1Val, &ESR2Val, &ESRVal );

    disableOCR2();
    
    f = ESRInterpolate( ESRVal );   
     
    USART_sprintf( "MODEESR: ESR1=%d(zero:%d)\r\nESR2=%d(zero:%d)\r\nESR=%d\r\nres*1000=%li\r\n\n", ESR1Val, s_ESR1_Zero, ESR2Val, s_ESR2_Zero, ESRVal, (uint32_t)(f*1000) );
                
    //round to 0.01
    f *= 100;
    f = ( uint32_t )( f + 0.5 );
    f /= 100;
    
    LCD_ShowNumber( f, 0.0099f, UNIT_OHMS );   
    
    if ( f < 99 )
    {
        resetIdle();
    }
    
    if ( checkSetZero() )
    {
        s_ESR1_Zero = ESR1Val;          
        s_ESR2_Zero = ESR2Val;          

        delay_ms( 1000 );
        LCD_HideCalibrate();
    }
}

//====================================================================
//====================================================================
void measure()
{
    switch( s_lastMode )
    {
    case MODE_R:
        LCD_ShowMode( "R  ");
        measureR();
        break;
        
    case MODE_L:
        LCD_ShowMode( "L  ");
        measureL();
        break;  
        
    case MODE_C:
        LCD_ShowMode( "C  ");
        measureC();
        break;
        
    case MODE_ESR:
        LCD_ShowMode( "ESR");
        measureESR();
        break;
        
    }
}

/*
//====================================================================
//====================================================================
void debugLC()
{
    float f;
    
    calibrateLC();

    while ( 1 )
    {
        measureL();
        LCD_ShowTrack();
        delay_ms(500);    
        LCD_HideTrack();
        delay_ms(1000);    
    }
        
    while( 1 )
    {       
        disableCCal();
        delay_ms( 500 );
        
        f = countLC();
        LCD_ShowNumber( f );
        delay_ms(1000);
                                           
        enableCCal();
        delay_ms( 500 );
        
        f = countLC();
        LCD_ShowNumber( f );

        LCD_ShowTrack();
        delay_ms(1000);

        LCD_HideTrack();
    }
}

//====================================================================
//====================================================================
void debugMode()
{
    int m;
    
    while( 1 )
    {
        m = getModeStable();
        LCD_ShowNumber( m );
        delay_ms(1000);
    }
}

//====================================================================
//====================================================================
void debugESR()
{
    uint16_t i1;
    uint16_t i2;
    uint16_t i3;
    

    while( 1 )             
    {
    
        prepareADC(0);
    
        i1 = readADC4();
        
        LCD_ShowST();
        LCD_ShowNumber( i1 );
        delay_ms(1000);
    }    
}
*/

//====================================================================
//====================================================================
void printESRCal()
{
    uint8_t i;
    
    for ( i = 0; i < ESR_CAL_COUNT; i++ )
    {
        USART_sprintf( "ESR_ADC_CAL%d=%d\r\n", i, s_ESR_ADC_CAL[ i ] );
    }
}

//====================================================================
//====================================================================
void checkDebugInput()
{
    unsigned char c;
    uint16_t v1,v2,v3;
    
    if ( USART_HasData() )
    {      
        c = USART_ReceiveChar();
        USART_TransmitChar( c ); 
        
        if ( c == 'c' )
        {
            USART_sprintf( "\r\n\nCommand:\r\n" ); 
            c = USART_ReceiveChar();
            USART_TransmitChar( c );
            //a - 1  0.05
            //b - 2  0.1
            //c - 3  0.2
            //d - 4  0.33
            //e - 5  0.6
            //f - 6  1
            //g - 7  2.2
            //h - 8  3.6
            //i - 9  4.7
            //j - 10  6.6
            //k - 11 10
            
            if ( ( c >= 'a' ) && ( c <= ( 'a' + ESR_CAL_COUNT ) ) )
            {        
                enableOCR2();
                delay_ms( 200 );

                GetESRADC( &v1, &v2, &v3 );
                
                disableOCR2();
                
                c -= 'a';
                c++;
                s_ESR_ADC_CAL[ c ] = v3; 
                USART_sprintf( "\r\nDone:%d\r\n\n\0",v3 );
            }
        }
        else
        {
            USART_sprintf( "\r\nUnknown\r\n\n\0" );
        } 

        s_ESR_ADC_CAL[ 0 ] = 0; 

        printESRCal();
         
    }
}    

//====================================================================
//====================================================================
void main(void)
{
    unsigned int i;
    
    configureHardware();
    
    POWER_HOLD = 0;  //hold power
                             
    LCD_Init();

// Global enable interrupts
    #asm("sei")
    
    resetIdle();
        
    while (1)
    {
        //check for idle    
        if (
                ( getTimer0Counter() - s_lastIdle > MAX_IDLE ) ||
                ( getTimer0Counter() > MAX_WORKING ) 
        )
        {
            //idle too long - turn off
            powerOff();
        }               
        
        //check for mode change
        i = getModeStable();
        
        if ( i != s_lastMode )
        {
            s_lastMode = i;
            prepareMode();
            
            resetIdle();
        }                                   
        
        measure();
                        
        checkPowerOff();
        
        LCD_ShowMeasurementReady();
        delay_ms(400);    

        checkPowerOff();

        LCD_HideMeasurementReady();
        delay_ms(700);

        checkPowerOff();
        
        checkDebugInput();
        checkLowPower();    
    }
}
