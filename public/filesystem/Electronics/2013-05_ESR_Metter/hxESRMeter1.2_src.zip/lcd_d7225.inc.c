#include <delay.h>
#include <stdbool.h>

//======================================================
//======================================================

static const __flash uint8_t s_data1[] = { 0xe8, 0xc0, 0x68, 0xe8, 0xc0, 0xa8, 0xa8, 0xe0, 0xe8, 0xe8 }; 
static const __flash uint8_t s_data2[] = { 0xa0, 0x00, 0xc1, 0x41, 0x61, 0x61, 0xe1, 0x00, 0xe1, 0x61 }; 
static const __flash uint8_t s_data3[] = { 0xfc, 0x0c, 0xd5, 0x9d, 0x2d, 0xb9, 0xf9, 0x1c, 0xfd, 0xbd }; 
static const __flash uint8_t s_data4[] = { 0xe2, 0x00, 0xca, 0x8a, 0x28, 0xaa, 0xea, 0x02, 0xea, 0xaa }; 
static const __flash uint8_t s_data5[] = { 0xac, 0xac, 0x24, 0xac, 0xac, 0x88, 0x88, 0xac, 0xac, 0xac }; 
static const __flash uint8_t s_data6[] = { 0x0f, 0x00, 0x2d, 0x29, 0x22, 0x2b, 0x2f, 0x01, 0x2f, 0x2b }; 

extern void LCD_WhiteSpace( uint8_t _pos );
extern void LCD_Clear();

//======================================================
//======================================================
void LCD_Send( unsigned char _value )
{
    int8_t i;
    for ( i = 7; i >=0; i-- )
    {
        LCD_DATA( ( _value >> i ) & 1 );
        LCD_CLK( 0 );
        delay_us(50);
        LCD_CLK( 1 );
        delay_us(100);
    } 
}

//======================================================
//======================================================
void LCD_Begin()
{
    LCD_CS( 0 ); //chip  select
    delay_us(600);
}

//======================================================
//======================================================
void LCD_End()
{
    LCD_CS( 1 ); //chip  select
    delay_us(100);
}

//======================================================
//======================================================
void LCD_Init()
{
    LCD_CS( 1 ); //chip unselect

    LCD_CLK( 1 ); //init clk
    delay_ms(1);

    LCD_Clear();
}

//======================================================
//======================================================
void LCD_Pointer( unsigned char _offset)
{
    LCD_Send( 0xe0 | _offset );
}


//======================================================
//======================================================
void LCD_DataCommand( unsigned char _value)
{
    LCD_Send( 0xd0 | _value );
}

//======================================================
//======================================================
void LCD_AndDataCommand( unsigned char _value)
{
    LCD_Send( 0x90 | (_value & 0xf ));
}

//======================================================
//======================================================
void LCD_OrDataCommand( unsigned char _value)
{
    LCD_Send( 0xb0 | _value );
}

//======================================================
//======================================================
//show digit at position
//pos == 0..7, _value = 0..9
void LCD_Digit( uint8_t _pos, uint8_t _value )
{
    uint8_t reg1;
    uint8_t reg2;
    uint8_t b;

    LCD_WhiteSpace( _pos );

    LCD_Begin();
        
    switch( _pos )
    {
        case 0:        
        case 1:        
        case 2:        
        case 3:        
        case 4:
            reg1 = _pos * 3;
            reg2 = 0x1c - _pos;
            
            LCD_Pointer( reg1 );
            b = s_data1 [ _value ];
            if ( _pos != 2 )
            {
                LCD_OrDataCommand( b >> 4 );
            }
            else
            {
                LCD_OrDataCommand( b >> 5 );
            }
            LCD_OrDataCommand( b & 0x0f );
            b = s_data2 [ _value ];
            LCD_OrDataCommand( b >> 4 );
            LCD_Pointer( reg2 );
            LCD_OrDataCommand( b & 0x0f );                      
            break;
            
        case 5:
            LCD_Pointer( 0x14 );
            b = s_data5 [ _value ];
            LCD_OrDataCommand( b & 0x0f );
            b = s_data6 [ _value ];
            LCD_OrDataCommand( b >> 4 );
            LCD_OrDataCommand( b & 0x0f );
            break;
            
        case 6:
            LCD_Pointer( 0x11 );
            b = s_data4 [ _value ];
            LCD_OrDataCommand( b >> 4 );
            LCD_OrDataCommand( b & 0xf );
            b = s_data5 [ _value ];
            LCD_OrDataCommand( b >> 4 );
            break;
              
        case 7:
            LCD_Pointer( 0x0f );
            b = s_data3 [ _value ];
            LCD_OrDataCommand( b & 0xf );
            LCD_OrDataCommand( b >> 4 );
            break;
    }
    
    LCD_End();
}

//======================================================
//======================================================
//clear digit at position
void LCD_WhiteSpace( uint8_t _pos )
{
    uint8_t reg1;
    uint8_t reg2;

    LCD_Begin();
        
    switch( _pos )
    {
        case 0:        
        case 1:        
        case 2:        
        case 3:        
        case 4:
            reg1 = _pos * 3;
            reg2 = 0x1c - _pos;
            
            LCD_Pointer( reg1 );
            if ( _pos != 2 )
            {
                LCD_AndDataCommand( ~0x0e );
            }
            else
            {
                LCD_AndDataCommand( ~0x07);
            }
            LCD_AndDataCommand(~0x08);
            LCD_AndDataCommand(~0x0e);
            LCD_Pointer( reg2 );
            LCD_AndDataCommand(~0x01);
            break;
            
        case 5:
            LCD_Pointer( 0x14 );
            LCD_AndDataCommand(~0x0c);
            LCD_AndDataCommand(~0x02);
            LCD_AndDataCommand(~0x0f);
            break;
            
        case 6:
            LCD_Pointer( 0x11 );
            LCD_AndDataCommand(~0x0e);
            LCD_AndDataCommand(~0x0a);
            LCD_AndDataCommand(~0x0a);
            break;
              
        case 7:
            LCD_Pointer( 0x0f );
            LCD_AndDataCommand(~0x0d);
            LCD_AndDataCommand(~0x0f);
            break;
    }
    
    LCD_End();
}


//======================================================
//======================================================
//show comma at position 1
void LCD_ShowComma1()
{
    LCD_Begin();
    LCD_Pointer( 6 );
    LCD_OrDataCommand( 8 );
    LCD_End();
}

//======================================================
//======================================================
//hide comma at position 1
void LCD_HideComma1()
{
    LCD_Begin();
    LCD_Pointer( 6 );
    LCD_AndDataCommand( ~8 );
    LCD_End();
}

//======================================================
//======================================================
//show comma at position 2
void LCD_ShowComma2()
{
    LCD_Begin();
    LCD_Pointer( 0x13 );
    LCD_OrDataCommand( 4 );
    LCD_End();
}

//======================================================
//======================================================
//hide comma at position 2
void LCD_HideComma2()
{
    LCD_Begin();
    LCD_Pointer( 0x13 );
    LCD_AndDataCommand( ~4 );
    LCD_End();
}

//======================================================
//======================================================
//show border symbol
void LCD_ShowBorder()
{
    LCD_Begin();
    LCD_Pointer( 0x11 );
    LCD_OrDataCommand( 1 );
    LCD_End();
}

//======================================================
//======================================================
//hide border symbol
void LCD_HideBorder()
{
    LCD_Begin();
    LCD_Pointer( 0x11 );
    LCD_AndDataCommand( ~1 );
    LCD_End();
}

//======================================================
//======================================================
void LCD_ShowST()
{
    LCD_Begin();
    LCD_Pointer( 0x09 );
    LCD_OrDataCommand( 1 );
    LCD_End();
}

//======================================================
//======================================================
void LCD_HideST()
{
    LCD_Begin();
    LCD_Pointer( 0x09 );
    LCD_AndDataCommand( ~1 );
    LCD_End();
}

//======================================================
//======================================================
void LCD_ShowBatLow()
{
    //show "MEGABASS" symbol
    LCD_Begin();
    LCD_Pointer( 0x17 );
    LCD_OrDataCommand( 1 );
    LCD_End();
}

//======================================================
//======================================================
void LCD_HideBatLow()
{
    //hide "MEGABASS" symbol
    LCD_Begin();
    LCD_Pointer( 0x17 );
    LCD_AndDataCommand( ~1 );
    LCD_End();
}

//======================================================
//======================================================
void LCD_ShowMeasurementReady()
{
    //show "Track" symbol
    LCD_Begin();
    LCD_Pointer( 0x0e );
    LCD_OrDataCommand( 1 );
    LCD_End();
}

//======================================================
//======================================================
void LCD_HideMeasurementReady()
{
    //hide "Track" symbol
    LCD_Begin();
    LCD_Pointer( 0x0e );
    LCD_AndDataCommand( ~1 );
    LCD_End();
}

//======================================================
//======================================================
//show minus symbol in position 7
void LCD_ShowMinus( uint8_t _pos )
{
    //LCD_Begin();
    //LCD_Pointer( 0x0e );
    //LCD_OrDataCommand( 1 );
    //LCD_End();
    
    LCD_Begin();
        
    switch( _pos )
    {
        case 0:        
        case 1:        
        case 2:        
        case 3:        
        case 4:
        case 5:
            break;
        case 6:
            LCD_Pointer( 0x11 );
            LCD_AndDataCommand(~0x0e);
            LCD_AndDataCommand(~0x0a);
            LCD_AndDataCommand(~0x0a);
            LCD_Pointer( 0x12 );
            LCD_OrDataCommand(0x08);
            break;
              
        case 7:
            LCD_Pointer( 0x0f );
            LCD_AndDataCommand(~0x0d);
            LCD_AndDataCommand(~0x0f);
            LCD_Pointer( 0x0f );
            LCD_OrDataCommand(0x01);
            break;
    }
    
    LCD_End();
    
}

//======================================================
//======================================================
//show number "_value / 100"
//max is 999.99
//two fractional digits
void LCD_ShowNumber1( uint32_t _value )
{
    uint32_t i;
    uint8_t lead;
    
    lead = 0;
    
    if ( _value > 99999 )
    {
        _value = 99999;
    }
                        
    LCD_ShowComma1();    
    
    i = _value / 10000;
    _value -= i * 10000;
    if( i != 0 )
    { 
        LCD_Digit( 4, i );
        lead = 1;
    }
    else
    {
        LCD_WhiteSpace( 4 );
    }
    
    i = _value / 1000;
    _value -= i * 1000;
    if( (i+lead) != 0 )
    { 
        LCD_Digit( 3, i );
        //lead = 1;
    }
    else
    {
        LCD_WhiteSpace( 3 );
    }

    i = _value / 100;
    _value -= i * 100;
    LCD_Digit( 2, i );

    i = _value / 10;
    _value -= i * 10;
    LCD_Digit( 1, i );

    LCD_Digit( 0, _value );
}

//======================================================
//======================================================
//show number at position 2 (digits 5,6,7)
//assuming _value is number
//-99..99 
void LCD_ShowNumber2( int8_t _value )
{
    uint8_t i;
    bool bNeg;
     
    bNeg = _value < 0;
    if ( bNeg )
    {         
        _value = -_value;
    }    

    if ( _value > 99 )
    {
        _value = 99;
    }
    
    if ( _value > 9 )
    {                  
        if ( bNeg )
        {
            LCD_ShowMinus( 7 );  
        }
        else
        {
            LCD_WhiteSpace( 7 );  
        }                
        
        i = _value / 10;
        _value -= i * 10;
        LCD_Digit( 6, i );

        i = _value;
        LCD_Digit( 5, i );
    }
    else
    {
        LCD_WhiteSpace( 7 );  

        if ( bNeg )
        {
            LCD_ShowMinus( 6 );  
        }
        else
        {
            LCD_WhiteSpace( 6 );  
        }                
        
        i = _value;
        LCD_Digit( 5, i );
    }                
    
}

//======================================================
//======================================================
void LCD_ShowCalibrate()
{
    uint8_t i;    
    LCD_ShowST();
    
    for ( i = 0; i < 8; i++ )
    {
        LCD_Digit( i, 0 );    
    }
}

//======================================================
//======================================================
void LCD_HideCalibrate()
{
    uint8_t i;    
    for ( i = 0; i < 8; i++ )
    {
        LCD_WhiteSpace( i );
    }            
    
    LCD_HideST();
}

//======================================================
//======================================================
void LCD_ShowNumber( float _value, float _ofs, uint8_t units )
{
    //show number in e6/e3/-/e-3/e-6/e-9/e-12 form
    //minimum is 0.1e12  
    float m;
    
    if ( _value >= 1e6 )
    {            
        if ( _value >= 999 * 1e6 )
        {    
            _value = 999 * 1e6;
        }           

        m = _value / 1e6;
        LCD_ShowNumber1( m * 100 );
        LCD_ShowNumber2( 6 );              
        LCD_ShowBorder();
    }
    else if ( _value >= 1e3 )
    {            
        m = _value / 1e3;
        LCD_ShowNumber1( m * 100 );
        LCD_ShowNumber2( 3 ); 
        LCD_ShowBorder();
    }
    else if ( _value >= _ofs )
    {            
        m = _value;
        LCD_ShowNumber1( m * 100 );
        LCD_WhiteSpace( 5 );
        LCD_WhiteSpace( 6 );
        LCD_WhiteSpace( 7 );
        LCD_HideBorder();
    }                    
    else if ( _value >= 1e-3 )
    {            
        m = _value * 1e3;
        LCD_ShowNumber1( m * 100 );
        LCD_ShowNumber2( -3 ); 
        LCD_ShowBorder();
    }                    
    else if ( _value >= 1e-6 )
    {            
        m = _value * 1e6;
        LCD_ShowNumber1( m * 100 );
        LCD_ShowNumber2( -6 ); 
        LCD_ShowBorder();
   }                    
    else if ( _value >= 1e-9 )
    {            
        m = _value * 1e9;
        LCD_ShowNumber1( m * 100 );
        LCD_ShowNumber2( -9 ); 
        LCD_ShowBorder();
    }                    
    else if ( _value >= 1e-13 )
    {            
        m = _value * 1e12;     
        LCD_ShowNumber1( m * 100 );
        LCD_ShowNumber2( -12 ); 
        LCD_ShowBorder();
    }
    else
    {
        LCD_ShowNumber1( 0 );
        LCD_WhiteSpace( 5 );
        LCD_WhiteSpace( 6 );
        LCD_WhiteSpace( 7 );
        LCD_HideBorder();
    }                    

}

//======================================================
//======================================================
void LCD_Clear()
{
    LCD_Begin();
   
    LCD_Send( 0x40 ); //mode set
    LCD_Send( 0x30 ); //unsynch transfer
    LCD_Send( 0x20 ); //clear data memory
    LCD_Send( 0x00 ); //clear blinking data memory
    LCD_Send( 0x14 ); //without segment decoder
   
    LCD_Send( 0x11 ); //display on
    
    LCD_End();
}


//======================================================
//======================================================
void LCD_ShowMode( const __flash char* _mode )
{
}
