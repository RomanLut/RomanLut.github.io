#include <stdio.h>
#include <graphics.h>
#include <math.h>

typedef struct	arrxy{double x,y;} arr;

int driver,mode;

void putgraphic(int x1,int y1,int x2,int y2,arr *ptr1,int n)
{
	int i;
	arr *ptr=ptr1;
	double maxx=ptr->x,maxy=ptr->y,minx=ptr->x,miny=ptr->y;
	double mx,my,x0,y0;
	for(i=0;i<n;i++,ptr++)
	{
		if (maxx<ptr->x) maxx=ptr->x;
		if (maxy<ptr->y) maxy=ptr->y;
		if (minx>ptr->x) minx=ptr->x;
		if (miny>ptr->y) miny=ptr->y;
	}
	mx=(x2-x1)/(maxx-minx);
	my=(y2-y1)/(maxy-miny);

	if(minx*maxx<0) line(x1+(int)(-minx*mx),y1,x1+(int)(-minx*mx),y2);
	if(miny*maxy<0) line(x1,(int)(-miny*my)+y1,x2,(int)(-miny*my)+y1);

	rectangle(x1,y1,x2,y2);
	for(i=0,ptr=ptr1;i<n;i++,ptr++)
		putpixel(x1+(int)((ptr->x-minx)*mx),y2-(int)((ptr->y-miny)*my),10);
}


arr qwe[1000];

void initarr()
{
	int i;
	arr *q=qwe;
	for(i=-500;i<500;i++,q++)
	{
		q->x=i/3.1415926/6.35;
		q->y=sin(q->x);
	}
}

void savearr(char* filename,arr* a, int n)
{
	FILE* f=fopen(filename,"tw");
	while(n--)
	{
		fprintf(f,"%f %f\n",a->x,a->y);
		a++;

	};
	fclose(f);
}

void loadarr(char* filename,arr* a,int n)
{
	FILE* f=fopen(filename,"tr");
	while(n-- && !feof(f))
	{
		fscanf(f,"%f %f\n",&a->x,&a->y);
		a++;

	};
	fclose(f);
}

main()
{
	int z;
	driver=DETECT;
	initgraph(&driver,&mode,"");
{	initarr();}
	loadarr("laga",qwe,1000);
	putgraphic(10,10,500,100,qwe,125);
	putgraphic(10,110,500,200,qwe,250);
	putgraphic(10,210,500,300,qwe,500);
	putgraphic(10,310,500,400,qwe,1000);
	getchar();
	closegraph();
	return 0;
}

