=================================
ReadManiac Localization kit v2.1
=================================


==============
Things to do: 
==============

1. Download ReadManiac package from the site

   http://www.deep-shadows.com/hax/ReadManiac.htm

   Build midlet for your phone. 
   At this stage you have ReadManiac.jar.

2. ReadManiac.jar is a simple ZIP archive.
   Rename it to ZIP and unpack with WinZip or WinRar.
   Make sure you are unpacking with subfolders.
   After unpacking, there should be "\res" subdirectory.

3. Translate "res\rmhelp.txt"
   Please credit yourself !

4. Translate "res\nofile.txt"

5. Translate "res\nospace.txt"

6. Translate "strings.txt" from this archive.

   "strings.xls" contains additional notes on each line of "strings.txt" - f.e. line should end with ":",
    should end with space etc.


==============================
How to build Localized midlet:
==============================

1. Run "encode.exe" and press button "Encode". "rm.dat" will be generated from "strings.txt"
   (make sure that encode.exe and strings.txt are placed in the same directory).

   Copy this "rm.dat" to "res\rm.dat" (overwrite).

2. Pack with WinZip and rename to "ReadManiac.jar"



=======
Testing
=======

 Please test that all strings fit properly. It probably will take several attempts before
all start to work fine. 

 If midlet does not work, try without replacing the images.

 CX65 and M65 should not be used for testing ! They have big screen and will not reflect situation
on phones with small screens. If you have phone with big screen, please test midlet in
phone emulator. 

 S55 emulator can be downloaded here:

 http://www.siemens-club.ru/soft-emul.php


===========
Other notes
===========

   Filenames are case sensetive ! Do not rename "rm.dat" to "RM.DAT" ! 

 When you are sure that all works fine, please send me translated files and images, and I will
place midlet on the site.

 Also please ask any questions conserning translation !


 Roman Lut
   hax@deep-shadows.com